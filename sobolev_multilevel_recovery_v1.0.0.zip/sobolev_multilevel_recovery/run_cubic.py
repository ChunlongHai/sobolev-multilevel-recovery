#!/usr/bin/env python3
"""Cubic recovery illustration; requires mpmath==1.3.0.

Portable invocation after `python -m pip install mpmath==1.3.0`:
    python run_cubic.py

No host-specific dependency paths are used by this script.  This is
high-precision floating computation, not interval-validated arithmetic.
"""
from __future__ import annotations

import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import mpmath
from mpmath import mp

from local_recovery import point_key, recover, uniform_recover


ROOT = Path(__file__).resolve().parent
EPSILONS = ["0.02", "0.002", "0.0002"]
METHODS = ["adaptive", "uniform"]
PRIMARY_DPS, REPEAT_DPS = 50, 80
TAU2 = "27/5"
CLUSTER_RADIUS = "1/32"  # Fixed BEFORE runs; diagnostic only.
DIRECT_CHECK = ("adaptive", "0.002")
MAX_QUERIES = 50000


def decimal(value, digits=85):
    return mp.nstr(value, digits)


def serial(value):
    if hasattr(value, "_mpf_"):
        return decimal(value)
    if isinstance(value, dict):
        return {k: serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    return value


def trace_hash(trace):
    encoded = json.dumps(trace, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def run_case(method, epsilon, dps, engine="heap"):
    # The callback and controller receive no peak location, norm or derivative.
    queried = []

    def evaluate(x):
        queried.append(point_key(x))
        return x - x ** 3

    fn = recover if method == "adaptive" else uniform_recover
    started = time.perf_counter()
    result = fn(evaluate, None, epsilon, tau_squared=TAU2, dps=dps,
                max_queries=MAX_QUERIES, engine=engine)
    elapsed = time.perf_counter() - started
    assert len(queried) == len(set(queried)) == result["query_count"]
    assert result["query_count"] == result["total_query_count"]
    with mp.workdps(dps):
        cells = list(zip(result["nodes"][:-1], result["nodes"][1:]))
        errors, locations, residual_energies = [], [], []
        for u, v in cells:
            h = v - u
            xstar = mp.sqrt((u * u + u * v + v * v) / 3)
            assert u < xstar < v
            errors.append((xstar - u) * (v - xstar) * (xstar + u + v))
            locations.append(xstar)
            midpoint = (u + v) / 2
            # Independent derivative-variance integral, in stable local form.
            residual_energies.append(3 * midpoint ** 2 * h ** 3 + h ** 5 / 20)
        actual_error = max(errors)
        actual_error_location = locations[errors.index(actual_error)]
        residual_energy2 = mp.fsum(residual_energies)
        independent_energy2 = mp.mpf(4) / 5 - residual_energy2
        energy_discrepancy = abs(result["energy2"] - independent_energy2)
        assert energy_discrepancy < mp.mpf(10) ** (-dps + 8)
        assert actual_error <= result["certificate"] <= mp.mpf(epsilon)
        if method == "uniform":
            assert result["query_count"] == result["background_n"] - 1

        # All following known-input geometry is AFTER-RUN diagnosis only.
        B = 2 / mp.sqrt(5)
        z = 1 / mp.sqrt(3)
        radius = mp.mpf(1) / 32
        internal = result["nodes"][1:-1]
        neighborhood_count = sum(abs(x - z) <= radius for x in internal)
        refinement_nodes = [Fraction(item["x"]) for item in result["trace"]
                            if item["kind"] == "refine"]
        refinement_near_peak = sum(abs(mp.mpf(x.numerator) / x.denominator - z) <= radius
                                   for x in refinement_nodes)
        # Exact rational proof per saved node: 3*x^2 != 1. A dyadic cannot
        # equal 1/sqrt(3); this check does not depend on comparing rounded z.
        peak_not_sampled = all(3 * Fraction(point_key(x)) ** 2 != 1 for x in internal)
        assert peak_not_sampled
        min_peak_distance = min(abs(x - z) for x in internal)
        row = {"method": method, "epsilon": epsilon, "dps": dps, "engine": engine,
               "query_count": result["query_count"],
               "total_query_count": result["total_query_count"],
               "background_n": result["background_n"],
               "stage_count": len(result["stages"]),
               "certificate": result["certificate"], "actual_error": actual_error,
               "actual_error_location": actual_error_location,
               "certificate_over_actual_error": result["certificate"] / actual_error,
               "true_B_diagnostic": B, "epsilon_over_B": mp.mpf(epsilon) / B,
               "cost_over_boundary_expression": result["query_count"] /
                   ((B / mp.mpf(epsilon)) ** (mp.mpf(2) / 3)),
               "energy2": result["energy2"], "maxabs": result["maxabs"],
               "residual_energy2_diagnostic": residual_energy2,
               "independent_energy_identity_discrepancy": energy_discrepancy,
               "peak_location_diagnostic": z, "peak_not_sampled_exact_rational": peak_not_sampled,
               "min_sample_distance_to_peak": min_peak_distance,
               "peak_neighborhood_radius": radius,
               "peak_neighborhood_count": neighborhood_count,
               "peak_neighborhood_fraction": mp.mpf(neighborhood_count) / len(internal),
               "peak_neighborhood_density_relative_to_uniform":
                   mp.mpf(neighborhood_count) / len(internal) / (2 * radius),
               "refinement_query_count": len(refinement_nodes),
               "refinement_near_peak_count": refinement_near_peak,
               "refinement_near_peak_fraction": (mp.mpf(refinement_near_peak) /
                   len(refinement_nodes)) if refinement_nodes else None,
               "trace_sha256": trace_hash(result["trace"]),
               "trace": result["trace"], "nodes": result["nodes"],
               "values": result["values"], "stages": result["stages"],
               "diagnostics": result["diagnostics"], "seconds": elapsed}
    return row, result


def main():
    # Freeze and record all choices and SOURCE hashes before the first query.
    metadata = {"run_status": "started", "function": "f(x)=x-x^3",
                "tau_squared_exact_rational_input": TAU2,
                "actual_norm_diagnostic_only": "2/sqrt(5)",
                "actual_peak_diagnostic_only": "1/sqrt(3)",
                "actual_maximum_diagnostic_only": "2/(3*sqrt(3))",
                "epsilons_fixed_before_runs": EPSILONS, "methods": METHODS,
                "primary_dps": PRIMARY_DPS, "repeat_dps": REPEAT_DPS,
                "primary_runs_planned": 6, "precision_repeats_planned": 6,
                "direct_reference_case_fixed_before_runs": list(DIRECT_CHECK),
                "diagnostic_peak_window_radius_fixed_before_runs": CLUSTER_RADIUS,
                "max_new_queries_per_run": MAX_QUERIES,
                "reuse_across_tolerances": False,
                "actual_error_method": "per-gap analytic stationary point, not sampled mesh",
                "trace_hash_rule": "sha256(json.dumps(trace,sort_keys=True,separators=(',',':')))",
                "arithmetic": "mpmath rounded arbitrary precision; not interval-certified",
                "python": sys.version, "platform": platform.platform(),
                "mpmath_version": mpmath.__version__,
                "source_sha256_before_first_run": {
                    p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in [Path(__file__), ROOT / "local_recovery.py"]}}
    output = {"metadata": metadata, "records": [], "precision_checks": [],
              "engine_reference_checks": []}
    path = ROOT / "cubic_results.json"

    def save():
        path.write_text(json.dumps(serial(output), indent=2) + "\n")

    save()
    print("PRE_RUN_MANIFEST " + json.dumps(metadata), flush=True)
    raw = {}
    for epsilon in EPSILONS:
        for method in METHODS:
            row, result = run_case(method, epsilon, PRIMARY_DPS)
            output["records"].append(row)
            raw[(method, epsilon)] = result
            save()
            print("PRIMARY " + json.dumps({k: serial(row[k]) for k in [
                "method", "epsilon", "query_count", "background_n", "certificate",
                "actual_error", "min_sample_distance_to_peak", "peak_neighborhood_fraction",
                "refinement_near_peak_fraction", "seconds"]}), flush=True)

    for epsilon in EPSILONS:
        for method in METHODS:
            row80, repeat = run_case(method, epsilon, REPEAT_DPS)
            primary = raw[(method, epsilon)]
            with mp.workdps(100):
                check = {"method": method, "epsilon": epsilon,
                         "primary_dps": PRIMARY_DPS, "repeat_dps": REPEAT_DPS,
                         "same_query_trace": primary["trace"] == repeat["trace"],
                         "same_final_nodes": primary["nodes"] == repeat["nodes"],
                         "same_background_n": primary["background_n"] == repeat["background_n"],
                         "same_stage_count": len(primary["stages"]) == len(repeat["stages"]),
                         "query_count_50": primary["query_count"], "query_count_80": repeat["query_count"],
                         "background_n_50": primary["background_n"], "background_n_80": repeat["background_n"],
                         "certificate_50": primary["certificate"], "certificate_80": repeat["certificate"],
                         "certificate_absolute_difference": abs(primary["certificate"] - repeat["certificate"]),
                         "certificate_relative_difference": abs(primary["certificate"] - repeat["certificate"]) /
                             repeat["certificate"],
                         "trace_sha256_50": trace_hash(primary["trace"]),
                         "trace_sha256_80": trace_hash(repeat["trace"]),
                         "trace_80": repeat["trace"], "nodes_80": repeat["nodes"],
                         "values_80": repeat["values"], "stages_80": repeat["stages"],
                         "diagnostics_50": primary["diagnostics"],
                         "diagnostics_80": repeat["diagnostics"], "seconds_80": row80["seconds"]}
            # Preserve a disagreement if one occurs; do not select/filter data.
            output["precision_checks"].append(check)
            save()
            print("PRECISION " + json.dumps({k: serial(check[k]) for k in [
                "method", "epsilon", "same_query_trace", "same_final_nodes",
                "same_background_n", "same_stage_count", "certificate_relative_difference"]}), flush=True)

    method, epsilon = DIRECT_CHECK
    direct_row, direct = run_case(method, epsilon, PRIMARY_DPS, engine="direct")
    primary = raw[DIRECT_CHECK]
    with mp.workdps(100):
        check = {"method": method, "epsilon": epsilon, "dps": PRIMARY_DPS,
                 "same_query_trace": primary["trace"] == direct["trace"],
                 "same_final_nodes": primary["nodes"] == direct["nodes"],
                 "same_background_n": primary["background_n"] == direct["background_n"],
                 "same_stage_count": len(primary["stages"]) == len(direct["stages"]),
                 "query_count_heap": primary["query_count"], "query_count_direct": direct["query_count"],
                 "certificate_heap": primary["certificate"], "certificate_direct": direct["certificate"],
                 "certificate_absolute_difference": abs(primary["certificate"] - direct["certificate"]),
                 "trace_sha256_heap": trace_hash(primary["trace"]),
                 "trace_sha256_direct": trace_hash(direct["trace"]),
                 "trace_direct": direct["trace"], "nodes_direct": direct["nodes"],
                 "values_direct": direct["values"], "stages_direct": direct["stages"],
                 "diagnostics_direct": direct["diagnostics"], "seconds_direct": direct_row["seconds"]}
    output["engine_reference_checks"].append(check)
    output["metadata"]["run_status"] = "complete"
    output["metadata"]["all_precision_traces_match"] = all(
        r["same_query_trace"] for r in output["precision_checks"])
    output["metadata"]["direct_trace_matches"] = check["same_query_trace"]
    save()
    excluded = {"trace", "nodes", "values", "stages", "diagnostics"}
    fields = [k for k in output["records"][0] if k not in excluded]
    with (ROOT / "cubic_results.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in output["records"]:
            writer.writerow({k: serial(row[k]) for k in fields})
    print("DIRECT " + json.dumps({k: serial(check[k]) for k in [
        "method", "epsilon", "same_query_trace", "query_count_heap", "query_count_direct",
        "certificate_absolute_difference", "seconds_direct"]}), flush=True)
    print("COMPLETE: all 6 predeclared primary cases, 6 precision repeats, 1 direct reference", flush=True)


if __name__ == "__main__":
    main()
