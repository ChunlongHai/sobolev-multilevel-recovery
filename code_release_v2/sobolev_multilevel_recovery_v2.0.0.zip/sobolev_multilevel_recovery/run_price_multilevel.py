"""Cumulative multilevel recovery with the price rule (Algorithm 2 of the manuscript).

Two synthetic hierarchies with alternating signs and shapes:
  boundary: the manuscript example (both shapes on the boundary of K_4);
  slack:    the same main bumps without the auxiliary bump, normalized,
            so every increment has positive slack (sigma ~ 0.30) in K_4.
Algorithms: 'price' (new) and 'holder' (the previous closed-form allocation,
for comparison). Algorithm inputs are only tau, q0, gamma, epsilon and the
cumulative query callback; the oracle alone knows beta and the shapes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

import numpy as np
from mpmath import mp

from local_stages import LocalStages
from local_recovery import point_key

ROOT = Path(__file__).resolve().parent


class Hierarchy:
    def __init__(self, model, beta):
        self.model = model
        self.q = mp.power(2, -mp.mpf(beta))
        self.t0 = mp.sqrt(1 - 5 * mp.pi ** 2 / 64)

        def dv(x):
            d = x - mp.mpf('0.5')
            a = 2 * mp.pi * d
            return (-2 * mp.pi * mp.cos(a) ** 3 * mp.sin(a)
                    + d * (1 - 16 * d * d) ** 2 * (1 - 64 * d * d) / 184)
        energy = mp.quad(lambda x: dv(x) ** 2,
                         [mp.mpf('0.25'), mp.mpf('0.5'), mp.mpf('0.75')])
        self.tv = mp.sqrt(1 - energy)
        self.np_ = mp.sqrt(5 * mp.pi ** 2 / 64)      # ||p||_H
        self.npv = mp.sqrt(energy)                    # ||p+v||_H
        self.cache, self.shape_cache = {}, {}
        self.calls = Counter()
        self.trace = []

    def slacks(self, tau=4):
        if self.model == 'boundary':
            return 0.0, 0.0
        t2 = tau * tau / 16.0
        return float(t2 / self.np_ ** 2 - 1), float(t2 / self.npv ** 2 - 1)

    def shapes(self, x):
        if x not in self.shape_cache:
            d, e = x - mp.mpf('0.5'), x - mp.mpf('0.1')
            main = abs(d) <= mp.mpf('0.25')
            p = mp.cos(2 * mp.pi * d) ** 4 / 4 if main else mp.mpf(0)
            v = d * d * (1 - 16 * d * d) ** 3 / 368 if main else mp.mpf(0)
            h = (2 * mp.cos(10 * mp.pi * e) ** 4 / (5 * mp.pi)
                 if abs(e) <= mp.mpf('0.05') else mp.mpf(0))
            if self.model == 'boundary':
                ge, go = p + self.t0 * h, p + v + self.tv * h
            else:
                ge, go = p / self.np_, (p + v) / self.npv
            self.shape_cache[x] = (ge, go)
        return self.shape_cache[x]

    def query(self, level, x):
        if level < 0 or x == 0 or x == 1:
            return mp.mpf(0)
        key = (level, x)
        if key not in self.cache:
            ge, go = self.shapes(x)
            q = self.q
            ne, no = level // 2 + 1, (level + 1) // 2
            self.cache[key] = ((1 - q ** (2 * ne)) * ge
                               - q * (1 - q ** (2 * no)) * go) / (1 - q * q)
            self.calls[level] += 1
            self.trace.append((level, point_key(x)))
        return self.cache[key]

    def target_float(self, x):
        d, e = x - .5, x - .1
        main = np.abs(d) <= .25
        p = np.where(main, np.cos(2 * np.pi * d) ** 4 / 4, 0)
        v = np.where(main, d * d * (1 - 16 * d * d) ** 3 / 368, 0)
        h = np.where(np.abs(e) <= .05, 2 * np.cos(10 * np.pi * e) ** 4 / (5 * np.pi), 0)
        if self.model == 'boundary':
            ge, go = p + float(self.t0) * h, p + v + float(self.tv) * h
        else:
            ge, go = p / float(self.np_), (p + v) / float(self.npv)
        q = float(self.q)
        return (ge - q * go) / (1 - q * q)


def recover(oracle, eps, *, tau=4, q0='0.5', gamma=1, pilot=16, rule='price'):
    eps, tau, q0 = mp.mpf(eps), mp.mpf(tau), mp.mpf(q0)
    rho = tau / (2 * mp.sqrt(pilot))
    D = tau / (2 * (1 - rho))
    KT = q0 / (2 * (1 - q0))
    amps = []
    for j in range(200):
        y = [mp.mpf(0)] + [oracle.query(j, mp.mpf(i) / pilot)
                           - oracle.query(j - 1, mp.mpf(i) / pilot)
                           for i in range(1, pilot)] + [mp.mpf(0)]
        a = D * mp.sqrt(pilot * mp.fsum((b - c) ** 2 for c, b in zip(y, y[1:])))
        if j:
            a = min(a, q0 * amps[-1])
        amps.append(a)
        if KT * a <= eps / 2:
            break
    active = [j for j, a in enumerate(amps) if a > 0]
    cost = {j: mp.power(2, gamma * j) for j in active}
    loc = {j: LocalStages(lambda x, j=j: oracle.query(j, x) - oracle.query(j - 1, x),
                          tau * tau) for j in active}
    if rule == 'price':
        for j in active:
            loc[j].advance()
        mu = 1 / eps
        rounds = 0
        while True:
            for j in active:
                while loc[j].cert > cost[j] * loc[j].n / mu:
                    loc[j].advance()
            if mp.fsum(loc[j].cert for j in active) <= eps / 2:
                break
            mu *= 2
            rounds += 1
    else:  # previous closed-form Hoelder allocation, r = 3/2
        r = mp.mpf(3) / 2
        w = {j: amps[j] ** (1 / (r + 1)) * cost[j] ** (r / (r + 1)) for j in active}
        S = mp.fsum(w.values())
        for j in active:
            tol = eps * w[j] / (2 * S)
            loc[j].advance()
            while loc[j].cert > tol:
                loc[j].advance()
        rounds = None
    tail = KT * amps[-1]
    cert = mp.fsum(loc[j].cert for j in active) + tail
    return dict(L=len(amps) - 1, cert=cert, tail=tail, loc=loc, rounds=rounds)


def run(model, beta, eps, rule, gamma, q0, dps=50):
    t = time.monotonic()
    with mp.workdps(dps):
        o = Hierarchy(model, beta)
        res = recover(o, eps, gamma=gamma, q0=q0, rule=rule)
        assert res['cert'] <= mp.mpf(eps)
        knots = sorted({float(x) for s in res['loc'].values() for x in s.nodes})
        grid = np.unique(np.r_[np.linspace(0, 1, 32769), knots,
                               .05, .1, .15, .25, .5, .75])
        approx = np.zeros_like(grid)
        for j, s in res['loc'].items():
            approx += np.interp(grid, [float(x) for x in s.nodes], [float(y) for y in s.values])
        err = float(np.max(np.abs(o.target_float(grid) - approx)))
        cost = sum(c * 2 ** (gamma * l) for l, c in o.calls.items())
        return dict(model=model, beta=beta, eps=eps, rule=rule, gamma=gamma, q0=q0,
                    cost=int(cost),
                    trace_sha256=hashlib.sha256(json.dumps(o.trace).encode()).hexdigest(), levels=res['L'] + 1, cert=float(res['cert']),
                    err=err, err_over_cert=err / float(res['cert']), rounds=res['rounds'], slacks=o.slacks(),
                    stages={j: s.n for j, s in res['loc'].items()},
                    level_cost={l: int(c * 2 ** (gamma * l)) for l, c in sorted(o.calls.items())},
                    seconds=round(time.monotonic() - t, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default='slack')
    ap.add_argument('--betas', nargs='+', default=['1'])
    ap.add_argument('--eps', nargs='+', default=['.02'])
    ap.add_argument('--rules', nargs='+', default=['price'])
    ap.add_argument('--gamma', type=float, default=1)
    ap.add_argument('--q0', default='0.5')
    ap.add_argument('--out', default=None)
    ap.add_argument('--dps', type=int, default=50)
    a = ap.parse_args()
    rows = []
    for beta in a.betas:
        for eps in a.eps:
            for rule in a.rules:
                row = run(a.model, beta, eps, rule, a.gamma, a.q0, a.dps)
                rows.append(row)
                print(json.dumps({k: row[k] for k in
                                  ['model', 'beta', 'eps', 'rule', 'cost', 'levels',
                                   'cert', 'err', 'seconds']}), flush=True)
                if a.out:
                    (ROOT / a.out).write_text(json.dumps(rows, indent=1) + '\n')


if __name__ == '__main__':
    main()
