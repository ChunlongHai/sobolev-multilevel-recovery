Code and numerical records
Version 2.0.0 (12 November 2026)

Accompanies:
Certified recovery from point values on Sobolev norm cones
(previously: Adaptive Certification of Multilevel Recovery on Sobolev Norm Cones)
Chunlong Hai, Yantao Li, and Jiazhen Wang

Changes in 2.0.0
----------------
The revised manuscript replaces the closed-form multilevel allocation by the
price rule (Algorithm 2), which covers increments with unknown positive slack.
- New: local_stages.py (stagewise Algorithm 1), run_price_multilevel.py
  (price rule; also the previous closed-form split as --rules holder),
  verify_price.py, and the records price_boundary_results.json (Figure 5),
  price_slack_results.json and closed_form_slack_results.json (Table 3),
  price_precision50.json and price_precision80.json (repeats).
- make_figures.py now draws the multilevel figure from the price-rule records;
  make_tables.py also writes slack_table.tex (Table 3).
- Unchanged: the single-level parabolic and cubic experiments and records.
- Kept for reference: run_multilevel.py, multilevel_results.json and
  multilevel_precision80.json, the version 1.0.0 closed-form allocation
  records. They are still checked by verify_results.py but no longer appear
  in the manuscript.

Installation
------------
Tested with Python 3.12, mpmath 1.3.0, and NumPy 2.3.5.
The price-rule records were produced with Python 3.9.6, mpmath 1.3.0 and
NumPy 2.0.2 (NumPy enters only the sampled error diagnostic).
Run the following commands from the extracted archive directory:

  python3 -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt

Check the supplied records
-------------------------

  python verify_results.py
  python verify_price.py

The first command checks source checksums, saved query counts, certificates, trace hashes,
precision comparisons, and error inequalities. It writes
numerics_verification.json and exits nonzero if a check fails.
It does not rerun the numerical experiments.
verify_price.py checks the price-rule records in the same way: coverage,
certificates, cost bookkeeping, identical 50/80-digit repeats (cost, stages
and query-trace hash), and the summary numbers quoted in the manuscript.

Regenerate the tables and figure sources
---------------------------------------

  python make_tables.py
  python make_figures.py --no-render

These commands regenerate the three tables and two TikZ figures from the saved
records. Figure previews in output/figures additionally require Tectonic with
pgfplots and pdftoppm; run make_figures.py without --no-render to render them.
The options --tectonic and --pdftoppm select the executables.

Rerun the experiments
--------------------

  python run_single_level.py --engine direct --output-prefix single_direct_reference
  python run_single_level.py --engine heap --compare-reference single_direct_reference.json
  python run_cubic.py
  python run_multilevel.py
  python run_multilevel.py --dps 80 --eps .02 .0005 --output multilevel_precision80.json
  python verify_results.py

Price-rule multilevel experiments (about ten minutes in total):

  python run_price_multilevel.py --model boundary --betas 1 1.5 2 --eps .02 .01 .005 .002 .001 .0005 --out price_boundary_results.json
  python run_price_multilevel.py --model slack --betas 1.5 2 --eps .02 .01 .005 .0025 --out price_slack_results.json
  python run_price_multilevel.py --model slack --betas 1.5 2 --eps .02 .01 .005 --rules holder --out closed_form_slack_results.json
  python run_price_multilevel.py --model boundary --betas 1 1.5 2 --eps .01 .001 --out price_precision50.json
  python run_price_multilevel.py --model boundary --betas 1 1.5 2 --eps .01 .001 --dps 80 --out price_precision80.json
  python verify_price.py

The single-level pair also compares direct scanning with the priority-queue
implementation. Reruns overwrite the corresponding numerical records.

Files
-----
local_recovery.py: point-query recovery and certificates.
run_single_level.py: parabolic input x(1-x), 42 primary cases and 8
  higher-precision repeats.
run_cubic.py: cubic input x-x^3, 6 primary cases, 6 higher-precision repeats,
  and a direct-scan comparison.
run_multilevel.py: alternating two-shape cumulative hierarchy with the
  version 1.0.0 closed-form allocation, 18 primary cases;
  multilevel_precision80.json contains its 6 higher-precision repeats.
local_stages.py: Algorithm 1 run one dyadic stage at a time.
run_price_multilevel.py: price-rule allocation (Algorithm 2) on the boundary
  hierarchy (18 cases, Figure 5) and on a hierarchy with slack 0.297 at every
  level (8 cases, Table 3), with the closed-form split for comparison
  (6 cases) and 6 boundary cases repeated at 50 and 80 digits.
*_results.json: observations, numerical results, and execution records.
verify_results.py and verify_price.py: saved-record consistency checks.
make_tables.py and make_figures.py: manuscript table and figure generation.
release.json: release version, source/data hashes, and checked case counts.
MANIFEST.sha256: checksums of all files in this release.

Numerical conventions
---------------------
Decisions use 50-digit mpmath arithmetic; selected runs are repeated at
80 digits. These computations evaluate the exact-model certificate formulas
with rounded arbitrary precision, rather than interval enclosures.
Parabolic and cubic interpolation errors use analytic gap formulas.
The multilevel error is a sampled diagnostic on a uniform grid augmented
with output knots and support endpoints; it is not an exact supremum and
does not control stopping. Runtime depends on the computing environment.

Source provenance
-----------------
The supplied records were regenerated with the release scripts on
4 November 2026. Their source hashes were captured before execution.
Query counts, traces, stopping stages, certificates, and error diagnostics
agree with the manuscript records. Scientific outputs were compared with
the previous records; runtime measurements may differ.

License
-------
The code, numerical records, and documentation in this release are provided
under the MIT License; see LICENSE.txt.
