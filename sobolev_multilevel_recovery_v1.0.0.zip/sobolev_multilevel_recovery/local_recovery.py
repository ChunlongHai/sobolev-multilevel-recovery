"""Data-only Brownian-bridge recovery, using mpmath (not interval arithmetic).

The adaptive routine implements manuscript Algorithm 3.1.  All decisions use
only queried values, the declared cone constant, and the tolerance.  The true
function's norm, derivatives, maximum location and slack are never inputs.
Install dependency: mpmath==1.3.0.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from fractions import Fraction
import heapq
from typing import Callable, Mapping

from mpmath import mp


def number(value):
    """Convert decimal/rational strings, Fractions, integers or mpf at current dps."""
    if isinstance(value, Fraction):
        return mp.mpf(value.numerator) / value.denominator
    if isinstance(value, str) and "/" in value:
        numerator, denominator = value.split("/", 1)
        return mp.mpf(numerator) / mp.mpf(denominator)
    return mp.mpf(value)


def point_key(x):
    """Exact rational identifier of an mpf; dyadic nodes compare across precision."""
    sign, mantissa, exponent, _ = x._mpf_
    numerator = -mantissa if sign else mantissa
    if exponent >= 0:
        return str(numerator << exponent)
    return f"{numerator}/{1 << (-exponent)}"


@dataclass(frozen=True)
class Polygon:
    nodes: tuple
    values: tuple

    def __call__(self, x):
        x = number(x)
        if not 0 <= x <= 1:
            raise ValueError("Evaluation point is outside [0,1]")
        index = min(bisect_right(self.nodes, x) - 1, len(self.nodes) - 2)
        u, v = self.nodes[index:index + 2]
        a, b = self.values[index:index + 2]
        return a + (b - a) * (x - u) / (v - u)


class RecoveryBudgetExceeded(RuntimeError):
    """The caller's finite computational budget was exhausted, not a theorem failure."""


class _Margins:
    def __init__(self):
        self.minimum = {}
        self.exact_zero_count = {}
        self.tests = {}

    def record(self, name, value):
        value = abs(value)
        self.tests[name] = self.tests.get(name, 0) + 1
        if not value:
            self.exact_zero_count[name] = self.exact_zero_count.get(name, 0) + 1
        elif name not in self.minimum or value < self.minimum[name]:
            self.minimum[name] = value

    def result(self):
        return {"minimum_nonzero_absolute_margin": dict(self.minimum),
                "exact_zero_count": dict(self.exact_zero_count),
                "branch_test_count": dict(self.tests)}


def certificate(power, witness_power, positive_budget, maxabs, tau2):
    """Lemma 2.1 at a data-derived q; no unknown residual enters this formula."""
    denominator = 1 - tau2 * witness_power ** 2
    if denominator <= 0:
        raise ArithmeticError("The witness certificate requires tau*q < 1")
    linear = tau2 * maxabs * witness_power
    root = mp.sqrt(linear ** 2 + denominator * positive_budget)
    return power * (linear + root) / denominator


def _activity_max(u, v, y0, y1, energy2, tau2):
    """Exact-form quadratic maximum over a gap (up to current mp rounding)."""
    h = v - u
    delta = y1 - y0
    quadratic = tau2 * (delta ** 2 - energy2 * h)
    linear = tau2 * (2 * y0 * delta + energy2 * h)
    maximum = max(tau2 * y0 ** 2 - energy2,
                  tau2 * y1 ** 2 - energy2)
    if quadratic < 0:
        t = -linear / (2 * quadratic)
        if 0 < t < 1:
            val = tau2 * (y0 + delta * t) ** 2 - energy2 * (
                1 - tau2 * h * t * (1 - t))
            maximum = max(maximum, val)
    return maximum


def recover(evaluate: Callable, tau, epsilon, *, dps=50, tau_squared=None,
            observations: Mapping | None = None, max_queries=200000,
            return_trace=True, mode="adaptive", engine="heap"):
    """Return a data-only approximation and computed Lemma 2.1 upper bound.

    ``observations`` is copied and never mutated. Known endpoints are free.
    ``query_count``/``cost`` count NEW calls to evaluate; ``total_query_count``
    counts all internal sampled nodes, including supplied observations.
    The evaluate callback may separately charge/cache cumulative F_j queries.
    Use tau_squared="16/3" for the parabolic boundary test, avoiding a
    square-root-then-square representation of the declared constant.

    Mode adaptive uses q_n=.5*sqrt(min(a_n,1/n)); uniform uses q=P_X.
    Both stop ONLY at the computed same-original-cone certificate <= epsilon.
    Selection is longest currently active gap, then leftmost. ``direct``
    recomputes global energy and all eligible gap activities after every
    insertion. The equivalent ``heap`` engine tests each popped gap using
    the latest GLOBAL energy; it never uses a stale activity value.

    Why lazy discard is valid: throughout each stage all gaps have length
    <=1/n, so 1-tau2*P_gap(x)^2>=1/2. On an unchanged gap, its polygon and
    power are fixed, and Phi(x)=tau2*s(x)^2-b2*(1-tau2*P_gap(x)^2) can only
    DECREASE as interpolation energy b2 increases. Thus an inactive gap
    cannot reactivate in that stage. Child gaps are tested afresh; every
    new background stage rebuilds the entire heap. The nonnegative
    midpoint energy increment is used during a stage, and full fsum
    energy is recomputed before every recorded certificate/stage boundary.
    """
    with mp.workdps(dps):
        tau2 = number(tau_squared) if tau_squared is not None else number(tau) ** 2
        eps = number(epsilon)
        if tau2 <= 4 or eps <= 0:
            raise ValueError("Require tau>2 and epsilon>0")
        if mode not in ("adaptive", "uniform"):
            raise ValueError("Unknown recovery mode")
        if engine not in ("direct", "heap"):
            raise ValueError("Unknown activity engine")
        data = {number(x): number(y) for x, y in (observations or {}).items()}
        if any(not 0 <= x <= 1 for x in data):
            raise ValueError("Observation nodes must lie in [0,1]")
        for endpoint in (mp.mpf(0), mp.mpf(1)):
            if endpoint in data and data[endpoint] != 0:
                raise ValueError("H_0^1 endpoint observations must be zero")
            data[endpoint] = mp.mpf(0)
        nodes = sorted(data)
        values = [data[x] for x in nodes]
        query_count = 0
        trace, stages = [], []
        margins = _Margins()

        def query(x, kind, stage):
            nonlocal query_count
            if x in data:
                return
            if query_count >= max_queries:
                raise RecoveryBudgetExceeded(
                    f"{mode}: max_queries={max_queries}, n={stage}")
            y = number(evaluate(x))
            if not mp.isfinite(y):
                raise ValueError("Point callback returned a nonfinite observation")
            data[x] = y
            index = bisect_left(nodes, x)
            nodes.insert(index, x)
            values.insert(index, y)
            query_count += 1
            if return_trace:
                trace.append({"n": stage, "kind": kind, "x": point_key(x)})

        def stats():
            energy2 = mp.fsum((values[i + 1] - values[i]) ** 2 /
                             (nodes[i + 1] - nodes[i])
                             for i in range(len(nodes) - 1))
            return energy2, max(abs(y) for y in values)

        n = 1
        while tau2 / (4 * n) > mp.mpf("0.5"):
            n *= 2
        for stage_index in range(40):
            for i in range(1, n):
                query(mp.mpf(i) / n, "background", n)
            energy2, maxabs = stats()
            if energy2 == 0:
                result = {"status": "success", "nodes": tuple(nodes),
                          "values": tuple(values), "energy2": energy2,
                          "maxabs": maxabs, "certificate": mp.mpf(0),
                          "query_count": query_count, "cost": query_count,
                          "total_query_count": len(nodes) - 2,
                          "background_n": n, "stages": stages, "trace": trace,
                          "diagnostics": margins.result(), "mode": mode,
                          "dps": dps, "tau_squared": tau2, "engine": engine}
                result["spline"] = Polygon(tuple(nodes), tuple(values))
                return result
            raw_observed_slack = tau2 * maxabs ** 2 / energy2 - 1
            margins.record("observed_slack_positive_part", raw_observed_slack)
            observed_slack = max(mp.mpf(0), raw_observed_slack)
            threshold = mp.mpf(1) / n ** 2 + observed_slack
            stage_refinements = 0
            if mode == "adaptive" and engine == "direct":
                while True:
                    energy2, maxabs = stats()
                    chosen = None
                    for index in range(len(nodes) - 1):
                        h = nodes[index + 1] - nodes[index]
                        margins.record("gap_threshold", h - threshold)
                        if h <= threshold:
                            continue
                        phi = _activity_max(nodes[index], nodes[index + 1],
                                            values[index], values[index + 1],
                                            energy2, tau2)
                        margins.record("activity_normalized", phi / energy2)
                        if phi >= 0 and (chosen is None or h > chosen[0]):
                            chosen = (h, index)
                    if chosen is None:
                        break
                    index = chosen[1]
                    query((nodes[index] + nodes[index + 1]) / 2, "refine", n)
                    stage_refinements += 1
            elif mode == "adaptive":
                pending = []

                def enqueue(u, v, y0, y1):
                    h = v - u
                    margins.record("gap_threshold", h - threshold)
                    if h > threshold:
                        heapq.heappush(pending, (-h, u, v, y0, y1))

                for i in range(len(nodes) - 1):
                    enqueue(nodes[i], nodes[i + 1], values[i], values[i + 1])
                while pending:
                    negative_h, u, v, y0, y1 = heapq.heappop(pending)
                    h = -negative_h
                    phi = _activity_max(u, v, y0, y1, energy2, tau2)
                    margins.record("activity_normalized", phi / energy2)
                    if phi < 0:
                        # Whole-stage monotonicity proof above permits discard.
                        continue
                    midpoint = (u + v) / 2
                    query(midpoint, "refine", n)
                    ym = data[midpoint]
                    energy2 += 4 * (ym - (y0 + y1) / 2) ** 2 / h
                    stage_refinements += 1
                    enqueue(u, midpoint, y0, ym)
                    enqueue(midpoint, v, ym, y1)
            energy2, maxabs = stats()
            maxgap = max(nodes[i + 1] - nodes[i] for i in range(len(nodes) - 1))
            power = mp.sqrt(maxgap) / 2
            q = mp.sqrt(min(threshold, mp.mpf(1) / n)) / 2 if mode == "adaptive" else power
            raw_budget = tau2 * maxabs ** 2 - energy2
            margins.record("budget_positive_part_normalized", raw_budget / energy2)
            bound = certificate(power, q, max(mp.mpf(0), raw_budget), maxabs, tau2)
            margins.record("stopping_normalized", (bound - eps) / eps)
            stages.append({"n": n, "observed_slack": observed_slack,
                           "threshold": threshold, "refinements": stage_refinements,
                           "total_query_count": len(nodes) - 2,
                           "energy2": energy2, "maxabs": maxabs,
                           "maxgap": maxgap, "power": power, "q": q,
                           "certificate": bound})
            if bound <= eps:
                return {"status": "success", "nodes": tuple(nodes),
                        "values": tuple(values), "energy2": energy2,
                        "maxabs": maxabs, "certificate": bound,
                        "query_count": query_count, "cost": query_count,
                        "total_query_count": len(nodes) - 2,
                        "background_n": n, "stages": stages, "trace": trace,
                        "diagnostics": margins.result(), "mode": mode,
                        "dps": dps, "tau_squared": tau2,
                        "engine": engine,
                        "spline": Polygon(tuple(nodes), tuple(values))}
            n *= 2
        raise RecoveryBudgetExceeded("Maximum of 40 dyadic stages exceeded")


def uniform_recover(evaluate, tau, epsilon, **kwargs):
    """Uniform dyadic designs; stop with Lemma 2.1 at q=P, not true error."""
    return recover(evaluate, tau, epsilon, mode="uniform", **kwargs)


__all__ = ["recover", "uniform_recover", "certificate", "Polygon",
           "RecoveryBudgetExceeded", "number", "point_key"]
