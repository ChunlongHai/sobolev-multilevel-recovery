"""Cumulative-query experiment for the manuscript's alternating hierarchy.

Algorithm inputs are only the cumulative callback, tau, q0, gamma and epsilon.
The synthetic oracle and diagnostics know beta and the two shapes. Decisions
use mpmath arithmetic, not interval arithmetic; the returned number is an
evaluation of the exact-model certificate, not a verified rounding enclosure.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

import numpy as np
from mpmath import mp

from local_recovery import recover, point_key

ROOT = Path(__file__).resolve().parent


class AlternatingHierarchy:
    """Synthetic data oracle, separated from the recovery algorithm."""
    def __init__(self, beta, dps):
        self.dps = dps
        self.q = mp.power(2, -mp.mpf(beta))
        self.t0 = mp.sqrt(1 - 5 * mp.pi**2 / 64)
        def derivative(x):
            d = x - mp.mpf('0.5')
            a = 2 * mp.pi * d
            dp = -2 * mp.pi * mp.cos(a)**3 * mp.sin(a)
            dv = d * (1-16*d*d)**2 * (1-64*d*d) / 184
            return dp + dv
        energy = mp.quad(lambda x: derivative(x)**2,
                         [mp.mpf('0.25'), mp.mpf('0.5'), mp.mpf('0.75')])
        self.tv = mp.sqrt(1-energy)
        self.shape_cache = {}
        self.cumulative_cache = {}
        self.calls = Counter()
        self.requests = 0
        self.trace = []

    def shapes(self, x):
        if x not in self.shape_cache:
            d = x-mp.mpf('0.5')
            p = mp.cos(2*mp.pi*d)**4/4 if abs(d) <= mp.mpf('0.25') else mp.mpf(0)
            v = d*d*(1-16*d*d)**3/368 if abs(d) <= mp.mpf('0.25') else mp.mpf(0)
            e = x-mp.mpf('0.1')
            h = 2*mp.cos(10*mp.pi*e)**4/(5*mp.pi) if abs(e) <= mp.mpf('0.05') else mp.mpf(0)
            self.shape_cache[x] = (p+self.t0*h, p+v+self.tv*h)
        return self.shape_cache[x]

    def query(self, level, x):
        if level < 0 or x == 0 or x == 1:
            return mp.mpf(0)
        self.requests += 1
        key = (level, x)
        if key not in self.cumulative_cache:
            g0, gv = self.shapes(x)
            ne, no = level//2+1, (level+1)//2
            value = ((1-self.q**(2*ne))*g0 -
                     self.q*(1-self.q**(2*no))*gv)/(1-self.q**2)
            self.cumulative_cache[key] = value
            self.calls[level] += 1
            self.trace.append((level, point_key(x)))
        return self.cumulative_cache[key]

    def target_float(self, x):
        """Double precision postprocessing only; never read by the algorithm."""
        x = np.asarray(x)
        d, e = x-.5, x-.1
        main = np.abs(d) <= .25
        auxiliary = np.abs(e) <= .05
        p = np.where(main, np.cos(2*np.pi*d)**4/4, 0)
        v = np.where(main, d*d*(1-16*d*d)**3/368, 0)
        h = np.where(auxiliary, 2*np.cos(10*np.pi*e)**4/(5*np.pi), 0)
        q = float(self.q)
        return ((p+float(self.t0)*h)-q*(p+v+float(self.tv)*h))/(1-q*q)


def cumulative_recovery(query, epsilon, *, dps=50, tau=4,
                        q0='0.5', gamma=1, pilot_intervals=16):
    """Algorithm 4.1. No amplitude, shape, beta or actual norm is an input."""
    with mp.workdps(dps):
        eps, tau, q0 = mp.mpf(epsilon), mp.mpf(tau), mp.mpf(q0)
        r = mp.mpf(3)/2
        rho = tau/(2*mp.sqrt(pilot_intervals))
        if not 0 < rho < 1:
            raise ValueError('The fixed pilot must be strict.')
        D = tau/(2*(1-rho))
        KT = q0/(2*(1-q0))
        amplitudes, pilot_energies = [], []
        for j in range(100):
            y = [mp.mpf(0)] + [query(j,mp.mpf(i)/pilot_intervals) -
                 query(j-1,mp.mpf(i)/pilot_intervals)
                 for i in range(1,pilot_intervals)] + [mp.mpf(0)]
            energy = pilot_intervals*mp.fsum((b-a)**2 for a,b in zip(y,y[1:]))
            amplitude = D*mp.sqrt(energy)
            if j:
                amplitude = min(amplitude,q0*amplitudes[-1])
            amplitudes.append(amplitude)
            pilot_energies.append(energy)
            if KT*amplitude <= eps/2:
                break
        else:
            raise RuntimeError('Finite experiment level budget exhausted.')
        active = [j for j,a in enumerate(amplitudes) if a > 0]
        if not active:
            return dict(L=j,certificate=mp.mpf(0),levels=[],tail=mp.mpf(0),pilot_energies=pilot_energies)
        weights = {j:amplitudes[j]**(1/(r+1))*mp.power(2,gamma*j*r/(r+1)) for j in active}
        total = mp.fsum(weights.values())
        levels = []
        for j in active:
            tol = eps*weights[j]/(2*total)
            # The local algorithm starts with no injected pilot observations.
            # Its calls reuse already obtained cumulative values via query().
            local = recover(lambda x,j=j:query(j,x)-query(j-1,x),tau,tol,
                            dps=dps,tau_squared=tau*tau,max_queries=100000)
            levels.append(dict(j=j,tolerance=tol,amplitude_bound=amplitudes[j],local=local))
        tail = KT*amplitudes[-1]
        bound = mp.fsum(row['local']['certificate'] for row in levels)+tail
        return dict(L=len(amplitudes)-1,certificate=bound,levels=levels,
                    tail=tail,pilot_energies=pilot_energies)


def run_case(beta, epsilon, dps=50):
    started = time.monotonic()
    with mp.workdps(dps):
        oracle = AlternatingHierarchy(beta,dps)
        result = cumulative_recovery(oracle.query,epsilon,dps=dps)
        eps = mp.mpf(epsilon)
        assert result['certificate'] <= eps
        level_rows = []
        grid = np.linspace(0.,1.,32769)
        # Additional queried nodes ensure the diagnostic includes interpolation
        # knots; this is still a sampled-error estimate, not an exact supremum.
        node_union = sorted({float(x) for row in result['levels'] for x in row['local']['nodes']})
        grid = np.unique(np.r_[grid,node_union,.05,.1,.15,.25,.5,.75])
        approximation = np.zeros_like(grid)
        local_node_total = 0
        for row in result['levels']:
            local = row['local']; local_node_total += local['total_query_count']
            approximation += np.interp(grid,list(map(float,local['nodes'])),list(map(float,local['values'])))
            level_rows.append(dict(level=row['j'],local_nodes=local['total_query_count'],
                new_cumulative_calls=oracle.calls[row['j']],cost=oracle.calls[row['j']]*(2**row['j']),
                tolerance=float(row['tolerance']),certificate=float(local['certificate']),
                amplitude_bound=float(row['amplitude_bound']),background_n=local['background_n'],
                trace_sha256=hashlib.sha256(json.dumps(local['trace']).encode()).hexdigest()))
        error = float(np.max(np.abs(oracle.target_float(grid)-approximation)))
        assert error <= float(result['certificate'])*(1+1e-12)
        beta_m = mp.mpf(beta)
        if beta_m < mp.mpf('1.5'): law=eps**(-1/beta_m)
        elif beta_m == mp.mpf('1.5'): law=eps**(-mp.mpf(2)/3)*mp.log(1/eps)**(mp.mpf(5)/3)
        else: law=eps**(-mp.mpf(2)/3)
        cost = sum(count*2**j for j,count in oracle.calls.items())
        return dict(beta=str(beta),epsilon=str(epsilon),dps=dps,status='success',
            weighted_query_cost=cost,total_cumulative_calls=sum(oracle.calls.values()),
            cumulative_requests=oracle.requests,cache_hits=oracle.requests-sum(oracle.calls.values()),
            sum_local_node_counts=local_node_total,opened_levels=result['L']+1,
            certificate=float(result['certificate']),certificate_high_precision=mp.nstr(result['certificate'],dps),
            tail_certificate=float(result['tail']),sampled_error=error,
            error_diagnostic='double precision on 32769 uniform points plus all output knots and support endpoints; not an exact supremum',
            cost_over_theoretical_order=float(cost/law),level_rows=level_rows,
            cumulative_trace_sha256=hashlib.sha256(json.dumps(oracle.trace).encode()).hexdigest(),
            t0=mp.nstr(oracle.t0,dps),tv=mp.nstr(oracle.tv,dps),seconds=time.monotonic()-started)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dps',type=int,default=50)
    parser.add_argument('--eps',nargs='+',default=['.02','.01','.005','.002','.001','.0005'])
    parser.add_argument('--betas',nargs='+',default=['1','1.5','2'])
    parser.add_argument('--output',default='multilevel_results.json')
    args=parser.parse_args()
    destination=ROOT/args.output
    rows=[]
    for beta in args.betas:
        for eps in args.eps:
            row=run_case(beta,eps,args.dps);rows.append(row)
            destination.write_text(json.dumps(dict(model='Alternating two-shape hierarchy (ex:alternating-hierarchy)',tau=4,q0=.5,gamma=1,A=1,
                pilot_intervals=16,arithmetic='mpmath; not interval-certified',rows=rows),indent=2)+'\n')
            print(json.dumps({k:row[k] for k in ['beta','epsilon','weighted_query_cost','opened_levels','certificate','sampled_error','seconds']}),flush=True)


if __name__=='__main__':main()
