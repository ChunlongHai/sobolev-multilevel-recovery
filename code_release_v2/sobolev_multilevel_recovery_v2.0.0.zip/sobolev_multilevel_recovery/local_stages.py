"""Stagewise form of Algorithm 3.1 (heap engine of local_recovery.recover).

``LocalStages`` runs the dyadic stages n0, 2n0, ... one at a time and keeps
its data, so a driver can pause a level after any stage and resume it later.
Stage logic, activity test and certificate are those of local_recovery.py;
only the stopping test is removed (the driver decides when to stop).
"""
from __future__ import annotations

from bisect import bisect_left
import heapq

from mpmath import mp

from local_recovery import certificate, _activity_max, number


class LocalStages:
    def __init__(self, evaluate, tau2, max_queries=2_000_000):
        self.evaluate = evaluate
        self.tau2 = number(tau2)
        self.data = {mp.mpf(0): mp.mpf(0), mp.mpf(1): mp.mpf(0)}
        self.nodes = [mp.mpf(0), mp.mpf(1)]
        self.values = [mp.mpf(0), mp.mpf(0)]
        self.queries = 0
        self.max_queries = max_queries
        n = 1
        while self.tau2 / (4 * n) > mp.mpf('0.5'):
            n *= 2
        self.n0 = n
        self.n = None            # last completed stage
        self.cert = None         # its certificate
        self.zero = False

    def _query(self, x):
        if x in self.data:
            return
        if self.queries >= self.max_queries:
            raise RuntimeError('local query budget exhausted')
        y = number(self.evaluate(x))
        self.data[x] = y
        i = bisect_left(self.nodes, x)
        self.nodes.insert(i, x)
        self.values.insert(i, y)
        self.queries += 1

    def _stats(self):
        nd, vl = self.nodes, self.values
        e2 = mp.fsum((vl[i + 1] - vl[i]) ** 2 / (nd[i + 1] - nd[i])
                     for i in range(len(nd) - 1))
        return e2, max(abs(y) for y in vl)

    def advance(self):
        """Complete the next dyadic stage; return its certificate."""
        if self.zero:
            return self.cert
        n = self.n0 if self.n is None else 2 * self.n
        tau2 = self.tau2
        for i in range(1, n):
            self._query(mp.mpf(i) / n)
        energy2, maxabs = self._stats()
        if energy2 == 0:
            self.n, self.cert, self.zero = n, mp.mpf(0), True
            return self.cert
        slack = max(mp.mpf(0), tau2 * maxabs ** 2 / energy2 - 1)
        threshold = mp.mpf(1) / n ** 2 + slack
        pending = []

        def enqueue(u, v, y0, y1):
            if v - u > threshold:
                heapq.heappush(pending, (-(v - u), u, v, y0, y1))

        for i in range(len(self.nodes) - 1):
            enqueue(self.nodes[i], self.nodes[i + 1],
                    self.values[i], self.values[i + 1])
        while pending:
            negh, u, v, y0, y1 = heapq.heappop(pending)
            h = -negh
            if _activity_max(u, v, y0, y1, energy2, tau2) < 0:
                continue
            m = (u + v) / 2
            self._query(m)
            ym = self.data[m]
            energy2 += 4 * (ym - (y0 + y1) / 2) ** 2 / h
            enqueue(u, m, y0, ym)
            enqueue(m, v, ym, y1)
        energy2, maxabs = self._stats()
        maxgap = max(self.nodes[i + 1] - self.nodes[i]
                     for i in range(len(self.nodes) - 1))
        power = mp.sqrt(maxgap) / 2
        q = mp.sqrt(min(threshold, mp.mpf(1) / n)) / 2
        budget = max(mp.mpf(0), tau2 * maxabs ** 2 - energy2)
        self.n = n
        self.cert = certificate(power, q, budget, maxabs, tau2)
        return self.cert
