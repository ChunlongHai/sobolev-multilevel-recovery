#!/usr/bin/env python3
"""Reproduce the single-level high-precision, data-only recovery experiments.

Example:
  python run_single_level.py
Dependency: mpmath==1.3.0. No plot generation and no interval-validity claim.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import mpmath
from mpmath import mp

from local_recovery import recover, uniform_recover, point_key


ROOT = Path(__file__).resolve().parent
EPSILONS = ["0.02", "0.01", "0.005", "0.002", "0.001", "0.0005", "0.0002"]
SIGMAS = ["0", "0.0001", "0.001"]
PRECISION_CHECKS = {("0", "0.0002"), ("0.0001", "0.0005"),
                    ("0.001", "0.002"), ("0.001", "0.0002")}


def decimal(value, digits=55):
    return mp.nstr(value, digits)


def serial(value, digits=55):
    if hasattr(value, "_mpf_"):
        return decimal(value, digits)
    if isinstance(value, dict):
        return {key: serial(val, digits) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(val, digits) for val in value]
    return value


def execute(method, sigma, eps, dps, max_queries, engine="heap"):
    tau2 = Fraction(16, 3) * (1 + Fraction(sigma))
    callback_points = []

    def evaluate(x):
        callback_points.append(point_key(x))
        return x * (1 - x)

    fn = recover if method == "adaptive" else uniform_recover
    started = time.perf_counter()
    result = fn(evaluate, None, eps, dps=dps, tau_squared=tau2,
                max_queries=max_queries, engine=engine)
    seconds = time.perf_counter() - started
    assert len(callback_points) == len(set(callback_points)) == result["query_count"]
    assert result["total_query_count"] == result["query_count"]
    with mp.workdps(dps):
        epsilon = mp.mpf(eps)
        true_B = 1 / mp.sqrt(3)  # DIAGNOSTICS ONLY, never passed to recovery.
        gaps = [b - a for a, b in zip(result["nodes"][:-1], result["nodes"][1:])]
        actual_error = max(gaps) ** 2 / 4
        exact_energy2 = (1 - mp.fsum(h ** 3 for h in gaps)) / 3
        energy_identity_discrepancy = abs(result["energy2"] - exact_energy2)
        assert energy_identity_discrepancy < mp.mpf(10) ** (-dps + 8)
        assert actual_error <= result["certificate"] <= epsilon
        if method == "uniform":
            assert result["query_count"] == result["background_n"] - 1
        proxy_work = ((true_B / epsilon) ** (mp.mpf(2) / 3)
                      + mp.mpf(sigma) * (true_B / epsilon) ** 2)
        trace_json = json.dumps(result["trace"], sort_keys=True, separators=(",", ":"))
        row = {"method": method, "engine": engine,
               "sigma": sigma, "epsilon": eps, "dps": dps,
               "epsilon_over_B": epsilon / true_B,
               "query_count": result["query_count"],
               "total_query_count": result["total_query_count"],
               "background_n": result["background_n"],
               "stage_count": len(result["stages"]),
               "certificate": result["certificate"],
               "actual_error": actual_error,
               "certificate_over_actual_error": result["certificate"] / actual_error,
               "cost_over_adaptive_theory_expression": result["query_count"] / proxy_work,
               "energy2": result["energy2"], "maxabs": result["maxabs"],
               "maxgap": max(gaps),
               "energy_identity_discrepancy": energy_identity_discrepancy,
               "tau_squared_exact_rational": str(tau2),
               "seconds": seconds,
               "trace_sha256": hashlib.sha256(trace_json.encode()).hexdigest(),
               "nodes": result["nodes"], "values": result["values"],
               "stages": result["stages"], "diagnostics": result["diagnostics"]}
    return row, result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-queries", type=int, default=50000)
    parser.add_argument("--engine", choices=["heap", "direct"], default="heap")
    parser.add_argument("--compare-reference", type=Path,
                        help="Optional previous direct-engine JSON, compared case by case.")
    parser.add_argument("--output-prefix", type=Path, default=ROOT / "single_results")
    parser.add_argument("--quick", action="store_true",
                        help="Only 3 tolerances per slack, still 50/80 digit checks.")
    args = parser.parse_args()
    json_path = args.output_prefix.with_suffix(".json")
    csv_path = args.output_prefix.with_suffix(".csv")
    reference = None
    if args.compare_reference:
        reference_data = json.loads(args.compare_reference.read_text())
        reference = {(r["method"], r["sigma"], r["epsilon"]): r
                     for r in reference_data["records"]}
    epsilons = ["0.02", "0.002", "0.0002"] if args.quick else EPSILONS
    metadata = {"python": sys.version, "platform": platform.platform(),
                "mpmath_version": mpmath.__version__, "primary_dps": 50,
                "check_dps": 80, "max_queries": args.max_queries,
                "engine": args.engine,
                "test_function": "f(x)=x(1-x)",
                "true_error_method": "max_gap_squared/4, exact analytic identity",
                "actual_norm_diagnostic_only": "1/sqrt(3)",
                "declared_tau_squared": "(16/3)*(1+sigma), exact rational input",
                "adaptive_q": "sqrt(min(a_n,1/n))/2, manuscript Algorithm 3.1",
                "uniform_q": "P_X=sqrt(max_gap)/2, Lemma 2.1",
                "selection": "longest currently active gap, then smallest left endpoint",
                "activity": ("direct global rescan after every insertion" if args.engine == "direct"
                             else "each popped gap retested with latest global energy; strict-pilot monotonicity permits lazy inactive discard"),
                "reuse_across_tolerances": False,
                "rounding_status": "mpmath high precision; NOT interval-certified",
                "source_sha256": {
                    p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in (ROOT / "local_recovery.py", Path(__file__))}}
    rows, checks, engine_checks = [], [], []
    raw_primary = {}
    for sigma in SIGMAS:
        for eps in epsilons:
            for method in ("adaptive", "uniform"):
                row, raw = execute(method, sigma, eps, 50, args.max_queries, args.engine)
                rows.append(row)
                if reference is not None:
                    before = reference[(method, sigma, eps)]
                    engine_check = {"method": method, "sigma": sigma, "epsilon": eps,
                                    "same_query_count": row["query_count"] == before["query_count"],
                                    "same_trace_sha256": row["trace_sha256"] == before["trace_sha256"],
                                    "same_certificate_decimal": decimal(row["certificate"]) == before["certificate"],
                                    "query_count": row["query_count"],
                                    "trace_sha256_reference": before["trace_sha256"],
                                    "trace_sha256_current": row["trace_sha256"],
                                    "certificate_reference": before["certificate"],
                                    "certificate_current": row["certificate"],
                                    "seconds_reference": before["seconds"],
                                    "seconds_current": row["seconds"]}
                    assert all(engine_check[k] for k in ("same_query_count", "same_trace_sha256", "same_certificate_decimal"))
                    engine_checks.append(engine_check)
                if (sigma, eps) in PRECISION_CHECKS:
                    raw_primary[(method, sigma, eps)] = raw
                print(json.dumps({k: serial(row[k], 16) for k in (
                    "method", "sigma", "epsilon", "query_count", "background_n",
                    "certificate", "actual_error", "seconds")}), flush=True)
                # Preserve completed observations if a later run is interrupted.
                json_path.write_text(
                    json.dumps(serial({"metadata": metadata, "records": rows,
                                       "precision_checks": checks,
                                       "engine_reference_checks": engine_checks}), indent=2) + "\n")
    for (method, sigma, eps), primary in raw_primary.items():
        row80, raw80 = execute(method, sigma, eps, 80, args.max_queries, args.engine)
        with mp.workdps(100):
            check = {"method": method, "sigma": sigma, "epsilon": eps,
                     "primary_dps": 50, "check_dps": 80,
                     "same_query_trace": primary["trace"] == raw80["trace"],
                     "same_final_nodes": primary["nodes"] == raw80["nodes"],
                     "trace_sha256_50": hashlib.sha256(json.dumps(primary["trace"], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
                     "trace_sha256_80": row80["trace_sha256"],
                     "query_count_50": primary["query_count"],
                     "query_count_80": raw80["query_count"],
                     "certificate_50": primary["certificate"],
                     "certificate_80": raw80["certificate"],
                     "certificate_absolute_difference": abs(primary["certificate"] - raw80["certificate"]),
                     "certificate_relative_difference": abs(primary["certificate"] - raw80["certificate"]) / raw80["certificate"],
                     "diagnostics_50": primary["diagnostics"],
                     "diagnostics_80": raw80["diagnostics"],
                     "seconds_80": row80["seconds"]}
        checks.append(check)
        print("PRECISION_CHECK " + json.dumps(serial(check, 18)), flush=True)
    # A zero strict pilot must terminate exactly; this checks the whole-cone zero path.
    zero = recover(lambda x: mp.mpf(0), None, "0.001", dps=50,
                   tau_squared="16/3")
    assert zero["certificate"] == 0 and zero["query_count"] == 3
    metadata["zero_input_check"] = {"query_count": zero["query_count"], "certificate": "0"}
    output = {"metadata": metadata, "records": rows, "precision_checks": checks,
              "engine_reference_checks": engine_checks}
    json_path.write_text(json.dumps(serial(output), indent=2) + "\n")
    excluded = {"nodes", "values", "stages", "diagnostics"}
    columns = [k for k in rows[0] if k not in excluded]
    with csv_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: serial(row[k]) for k in columns})
    print(f"WROTE {len(rows)} primary rows and {len(checks)} precision checks", flush=True)


if __name__ == "__main__":
    main()
