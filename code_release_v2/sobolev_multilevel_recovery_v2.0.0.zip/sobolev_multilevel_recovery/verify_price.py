#!/usr/bin/env python3
"""Check the saved price-rule multilevel records without rerunning them.

Uses only the standard library. Checks case coverage, certificate validity
(0 <= sampled error <= certificate <= epsilon), cost bookkeeping, the
50/80-digit repeats (identical cost, stages, levels and query-trace hash),
and the summary numbers quoted in the manuscript. Writes
price_verification.json and exits nonzero if a check fails.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
HASH = re.compile(r"[0-9a-f]{64}\Z")
FILES = {
    "boundary": "price_boundary_results.json",
    "slack": "price_slack_results.json",
    "closed_form": "closed_form_slack_results.json",
    "precision50": "price_precision50.json",
    "precision80": "price_precision80.json",
}
EXPECTED = {
    "boundary": {("boundary", "price", b, e) for b in ("1", "1.5", "2")
                 for e in (".02", ".01", ".005", ".002", ".001", ".0005")},
    "slack": {("slack", "price", b, e) for b in ("1.5", "2")
              for e in (".02", ".01", ".005", ".0025")},
    "closed_form": {("slack", "holder", b, e) for b in ("1.5", "2")
                    for e in (".02", ".01", ".005")},
    "precision50": {("boundary", "price", b, e) for b in ("1", "1.5", "2")
                    for e in (".01", ".001")},
    "precision80": {("boundary", "price", b, e) for b in ("1", "1.5", "2")
                    for e in (".01", ".001")},
}


def key(r):
    return (r["model"], r["rule"], r["beta"], r["eps"])


def main() -> int:
    raw = {n: (HERE / f).read_bytes() for n, f in FILES.items()}
    data = {n: {key(r): r for r in json.loads(b)} for n, b in raw.items()}
    checks, failures = [], []

    def check(name, ok, detail=""):
        checks.append(dict(name=name, passed=bool(ok), detail=detail))
        if not ok:
            failures.append(name)

    for n, rows in data.items():
        check(f"{n}:coverage", set(rows) == EXPECTED[n],
              f"{len(rows)} records")
        for k, r in rows.items():
            tag = f"{n}:{'|'.join(k)}"
            eps = float(r["eps"])
            check(tag + ":certificate", 0 <= r["err"] <= r["cert"] <= eps,
                  f"err={r['err']:.6g} cert={r['cert']:.6g} eps={eps}")
            check(tag + ":cost", sum(r["level_cost"].values()) == r["cost"])
            check(tag + ":trace_hash", bool(HASH.match(r.get("trace_sha256", ""))))
            check(tag + ":gamma_q0", r["gamma"] == 1 and r["q0"] == "0.5")

    for k, r in data["precision80"].items():
        for ref_name in ("precision50", "boundary"):
            ref = data[ref_name][k]
            same = all(r[f] == ref[f] for f in ("cost", "levels", "stages",
                                                  "level_cost", "trace_sha256"))
            check(f"precision80_vs_{ref_name}:{'|'.join(k)}", same)

    # Summary numbers quoted in the manuscript.
    price_runs = list(data["boundary"].values()) + list(data["slack"].values())
    ratios = [r["err_over_cert"] for r in price_runs]
    check("discrepancy_range_26_runs",
          len(price_runs) == 26 and round(100 * min(ratios), 2) == 0.88
          and round(100 * max(ratios), 2) == 2.75,
          f"{100 * min(ratios):.2f}%-{100 * max(ratios):.2f}%")
    for beta in ("1.5", "2"):
        scaled = [r["cost"] * float(r["eps"]) ** 2 for k, r in data["slack"].items()
                  if k[2] == beta]
        check(f"slack_eps2_cost_spread_beta{beta}", max(scaled) / min(scaled) <= 1.05,
              f"{min(scaled):.2f}-{max(scaled):.2f}")
    ratio = [data["closed_form"][k]["cost"] / data["slack"][("slack", "price") + k[2:]]["cost"]
             for k in data["closed_form"]]
    check("closed_form_ratio_range", round(min(ratio), 1) == 2.6 and round(max(ratio), 1) == 4.1,
          f"{min(ratio):.2f}-{max(ratio):.2f}")
    costs = {r["beta"]: r["cost"] for r in data["boundary"].values() if r["eps"] == ".0005"}
    check("boundary_costs_eps_5e-4", costs == {"1": 1123305, "1.5": 143881, "2": 38031},
          json.dumps(costs))

    report = dict(
        status="passed" if not failures else "failed",
        checks=len(checks), failures=failures,
        record_sha256={FILES[n]: hashlib.sha256(b).hexdigest() for n, b in raw.items()},
        details=checks,
    )
    (HERE / "price_verification.json").write_text(json.dumps(report, indent=1) + "\n")
    print(f"{report['status']}: {len(checks) - len(failures)}/{len(checks)} checks passed")
    for f in failures:
        print("FAILED", f)
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
