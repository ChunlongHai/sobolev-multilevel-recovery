#!/usr/bin/env python3
"""Generate manuscript table fragments and CSV records from saved results.

No experiment is rerun. single_table.tex contains the four original rows;
cubic_table.tex is generated when cubic_results.json is present; slack_table.tex
is the positive-slack multilevel table (price rule vs closed-form split). The .tex
outputs contain only tabular environments, without floats or captions.
"""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, ROUND_HALF_EVEN, localcontext
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def dec(value):
    return value if isinstance(value, Decimal) else Decimal(str(value))


def tex_number(value, digits=5):
    """Scientific notation, rounded half-even to the stated significant digits."""
    value = dec(value)
    if not value.is_finite():
        raise ValueError("Nonfinite table value")
    if not value:
        return "0"
    with localcontext() as context:
        context.rounding = ROUND_HALF_EVEN
        mantissa, exponent = format(value, f".{digits-1}E").split("E")
    mantissa = mantissa.rstrip("0").rstrip(".")
    if mantissa == "1" and int(exponent):
        return "10^{"+str(int(exponent))+"}"
    return mantissa if int(exponent) == 0 else mantissa+r"\times10^{"+str(int(exponent))+"}"


def math(value):
    return "$"+tex_number(value)+"$"


def select_one(records, method, epsilon, sigma=None):
    selected = [row for row in records if row["method"] == method
                and dec(row["epsilon"]) == dec(epsilon)
                and (sigma is None or dec(row["sigma"]) == dec(sigma))]
    if len(selected) != 1:
        raise ValueError(f"Expected one record: {method}, epsilon={epsilon}, sigma={sigma}")
    row = selected[0]
    if row["dps"] != 50 or not 0 <= dec(row["actual_error"]) <= dec(row["certificate"]) <= dec(epsilon):
        raise ValueError("Table record fails primary precision/error/certificate check")
    return row


def write_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tabular(headers, rows, columns):
    return "\n".join([r"\begin{tabular}{"+columns+"}", r"\toprule",
                      " & ".join(headers)+r"\\", r"\midrule",
                      *(" & ".join(row)+r"\\" for row in rows),
                      r"\bottomrule", r"\end{tabular}", ""])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=HERE)
    args = parser.parse_args()
    directory = args.directory
    inputs, outputs, selections = {}, [], {}
    if not (directory/"cubic_results.json").is_file() and any(
            (directory/name).exists() for name in ("cubic_table.tex", "cubic_table.csv")):
        raise ValueError("Cubic input is absent but generated cubic tables remain; "
                         "restore cubic_results.json or remove those stale outputs first")

    def load(name):
        raw = (directory/name).read_bytes()
        inputs[name] = raw
        return json.loads(raw, parse_float=Decimal)

    original = load("single_results.json")
    specs = [("uniform", "0"), ("adaptive", "0"),
             ("adaptive", "0.0001"), ("adaptive", "0.001")]
    single = [select_one(original["records"], method, "0.0002", sigma)
              for method, sigma in specs]
    display = [[r["method"].capitalize(), math(r["sigma"]), str(r["query_count"]),
                math(r["certificate"]), math(r["actual_error"])] for r in single]
    (directory/"single_table.tex").write_text(tabular(
        ["Method", r"$\sigma$", "Queries", r"$\mathcal E$", "Actual error"], display, "llrrr"))
    write_csv(directory/"single_table.csv", [
        {name: r[name] for name in ("method", "sigma", "epsilon", "query_count",
                                    "certificate", "actual_error", "trace_sha256")}
        for r in single])
    outputs.extend(["single_table.tex", "single_table.csv"])
    selections["single_table"] = [dict(method=m, sigma=s, epsilon="0.0002") for m, s in specs]

    if (directory/"cubic_results.json").is_file():
        cubic = load("cubic_results.json")
        tolerances = sorted({dec(r["epsilon"]) for r in cubic["records"]}, reverse=True)
        if len(tolerances) != 3 or len(cubic["records"]) != 6:
            raise ValueError("The compact cubic table requires three tolerances and two methods")
        data, display = [], []
        for epsilon in tolerances:
            adaptive = select_one(cubic["records"], "adaptive", epsilon)
            uniform = select_one(cubic["records"], "uniform", epsilon)
            data.append(dict(epsilon=str(epsilon), adaptive_queries=adaptive["query_count"],
                uniform_queries=uniform["query_count"], adaptive_certificate=adaptive["certificate"],
                adaptive_actual_error=adaptive["actual_error"],
                adaptive_trace_sha256=adaptive["trace_sha256"], uniform_trace_sha256=uniform["trace_sha256"]))
            display.append([math(epsilon), str(adaptive["query_count"]), str(uniform["query_count"]),
                            math(adaptive["certificate"]), math(adaptive["actual_error"])])
        (directory/"cubic_table.tex").write_text(tabular(
            [r"$\varepsilon$", r"$N_{\rm ad}$", r"$N_{\rm unif}$",
             r"$\mathcal E_{\rm ad}$", r"Error$_{\rm ad}$"], display, "rrrrr"))
        write_csv(directory/"cubic_table.csv", data)
        outputs.extend(["cubic_table.tex", "cubic_table.csv"])
        selections["cubic_table"] = [dict(epsilon=str(e), methods=["adaptive", "uniform"])
                                      for e in tolerances]
        cubic_status = "generated"
    else:
        cubic_status = "not_present; cubic table not generated"

    # Table 3: positive-slack hierarchy, price rule vs closed-form split.
    price = load("price_slack_results.json")
    closed = {(r["beta"], r["eps"]): r for r in load("closed_form_slack_results.json")}

    def thousands(n):
        return f"{int(n):,}".replace(",", "{,}")

    lines, data = [], []
    for beta in ("1.5", "2"):
        group = sorted([r for r in price if r["beta"] == beta and r["rule"] == "price"
                        and r["model"] == "slack"], key=lambda r: -float(r["eps"]))
        if len(group) != 4:
            raise ValueError(f"Slack table needs four tolerances for beta={beta}")
        if lines:
            lines.append(r"\addlinespace")
        for r in group:
            eps = float(r["eps"])
            if not 0 <= r["err"] <= r["cert"] <= eps:
                raise ValueError("Slack record fails error/certificate check")
            h = closed.get((beta, r["eps"]))
            mant, ex = ("%.1e" % eps).split("e")
            cells = [f"${beta}$", "$%s\\times10^{%d}$" % (mant.rstrip("0").rstrip("."), int(ex)),
                     str(r["levels"]), thousands(r["cost"]), f"{r['cost'] * eps * eps:.2f}",
                     thousands(h["cost"]) if h else "---",
                     f"{h['cost'] / r['cost']:.2f}" if h else "---"]
            lines.append(" & ".join(cells) + r"\\")
            data.append(dict(beta=beta, epsilon=r["eps"], levels=r["levels"], price_cost=r["cost"],
                             eps2_cost=r["cost"] * eps * eps, closed_form_cost=h["cost"] if h else "",
                             price_trace_sha256=r["trace_sha256"]))
    (directory/"slack_table.tex").write_text("\n".join(
        [r"\begin{tabular}{llrrrrr}", r"\toprule",
         r"$\beta$ & $\varepsilon$ & Levels & Cost & $\varepsilon^2\cdot$Cost &", r"Closed form & Ratio\\",
         r"\midrule", *lines, r"\bottomrule", r"\end{tabular}", ""]))
    write_csv(directory/"slack_table.csv", data)
    outputs.extend(["slack_table.tex", "slack_table.csv"])
    selections["slack_table"] = "price_slack_results.json (all rows), closed_form_slack_results.json"

    manifest = dict(generator="make_tables.py", generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        source_sha256={name: hashlib.sha256(raw).hexdigest() for name, raw in inputs.items()},
        output_sha256={name: hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in outputs},
        rounding="Displayed nonzero values: five significant digits, Decimal ROUND_HALF_EVEN; trailing zeros suppressed. CSV retains input digits.",
        selections=selections, cubic_status=cubic_status,
        scope="Saved-data extraction only; tabular fragments have no caption/float and require booktabs.")
    (directory/"tables_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    if any((directory/name).read_bytes() != raw for name, raw in inputs.items()):
        raise RuntimeError("Input results changed during table generation")
    print("Generated "+", ".join(outputs+["tables_manifest.json"]))


if __name__ == "__main__":
    main()
