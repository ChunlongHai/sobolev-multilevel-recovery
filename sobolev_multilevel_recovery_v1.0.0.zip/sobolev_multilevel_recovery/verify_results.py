#!/usr/bin/env python3
"""Check saved experiment summaries without rerunning either algorithm.

Uses only the standard library. Legacy traces are compared through saved
SHA256 values; the additional cubic archive retains raw ordered traces,
which are rehashed directly. Decimal preserves serialized certificate digits.
"""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import sys


HERE = Path(__file__).resolve().parent
CERT_REL_TOL = Decimal("1e-40")
FLOAT_REL_TOL = Decimal("2e-14")
HASH = re.compile(r"[0-9a-f]{64}\Z")


def dec(value):
    return value if isinstance(value, Decimal) else Decimal(str(value))


def difference(a, b):
    a, b = dec(a), dec(b)
    absolute = abs(a - b)
    relative = absolute / abs(b) if b else absolute
    return absolute, relative


def close(a, b, tolerance=FLOAT_REL_TOL):
    a, b = dec(a), dec(b)
    return abs(a-b) <= tolerance * max(abs(a), abs(b), Decimal("1e-100"))


def key(row, single=False):
    names = ("method", "sigma", "epsilon") if single else ("beta", "epsilon")
    return tuple(row[k] if k == "method" else str(dec(row[k]).normalize())
                 for k in names)


def indexed(rows, single=False):
    result = {key(row, single): row for row in rows}
    if len(result) != len(rows):
        raise ValueError("Duplicate experiment key in saved records")
    return result


def maximum(rows, field):
    if not rows:
        return {"value": None, "case": None}
    row = max(rows, key=lambda r: dec(r[field]))
    return {"value": row[field], "case": row["case"]}


def verify_cubic(directory):
    """Check the additional archive, including its retained raw ordered traces."""
    path = directory/"cubic_results.json"
    raw = path.read_bytes()
    saved = json.loads(raw, parse_float=Decimal)
    checks, precision_summary = [], []

    def record(name, errors=(), **details):
        checks.append(dict(name=name, passed=not errors, errors=list(errors), **details))

    def require(errors, condition, description):
        if not condition:
            errors.append(description)

    def cubic_key(row):
        return row["method"], str(dec(row["epsilon"]).normalize())

    def index(rows):
        result = {cubic_key(r): r for r in rows}
        if len(result) != len(rows):
            raise ValueError("Duplicate cubic experiment key")
        return result

    def trace_check(errors, trace, nodes, stages, count, expected_hash):
        digest = hashlib.sha256(json.dumps(trace, sort_keys=True,
                                          separators=(",", ":")).encode()).hexdigest()
        require(errors, digest == expected_hash, "Retained raw ordered trace does not match SHA256")
        coordinates = [Fraction(t["x"]) for t in trace]
        require(errors, len(trace) == count == len(set(coordinates)),
                "Raw trace count/unique-query ledger failed")
        require(errors, set(coordinates) == {Fraction(x) for x in nodes[1:-1]},
                "Raw queried coordinate set differs from final internal nodes")
        require(errors, all(0 < x < 1 and x.denominator & (x.denominator-1) == 0
                            for x in coordinates), "Raw trace has a noninterior or nondyadic query")
        require(errors, all(t["kind"] in ("background", "refine") for t in trace),
                "Unknown raw query kind")
        stage_numbers = [t["n"] for t in trace]
        require(errors, stage_numbers == sorted(stage_numbers), "Raw query stages are out of order")
        require(errors, all(n >= 4 and n & (n-1) == 0 for n in stage_numbers),
                "Raw query stages violate the cubic dyadic background schedule")
        require(errors, {t["n"] for t in trace} == {s["n"] for s in stages},
                "Raw query stage set differs from saved stages")

    metadata = saved["metadata"]
    errors = []
    require(errors, metadata["run_status"] == "complete", "Cubic batch is incomplete")
    require(errors, Fraction(metadata["tau_squared_exact_rational_input"]) == Fraction(27, 5),
            "Declared cubic cone differs from tau^2=27/5")
    require(errors, metadata["primary_dps"] == 50 and metadata["repeat_dps"] == 80,
            "Cubic precisions differ from 50/80")
    require(errors, metadata["reuse_across_tolerances"] is False, "Cubic run metadata permits cross-tolerance reuse")
    for name, expected_hash in metadata["source_sha256_before_first_run"].items():
        require(errors, hashlib.sha256((directory/name).read_bytes()).hexdigest() == expected_hash,
                f"Cubic pre-run source checksum differs: {name}")
    record("cubic_metadata", errors)
    expected = {(m, e) for m in ("adaptive", "uniform")
                for e in ("0.02", "0.002", "0.0002")}
    primary = index(saved["records"])
    record("cubic_primary_coverage", [] if set(primary) == expected else
           ["Expected six primary cubic cases"], count=len(primary))
    for case, row in primary.items():
        errors = []
        nodes, values = list(map(dec, row["nodes"])), list(map(dec, row["values"]))
        require(errors, row["dps"] == 50 and row["engine"] == "heap", "Cubic primary precision/engine differs")
        require(errors, len(nodes) == len(values) == row["query_count"]+2
                and row["query_count"] == row["total_query_count"], "Cubic query/node ledger failed")
        require(errors, nodes[0] == 0 and nodes[-1] == 1
                and all(v > u for u, v in zip(nodes, nodes[1:])), "Cubic partition is invalid")
        require(errors, all(close(y, x-x**3, CERT_REL_TOL) for x, y in zip(nodes, values)),
                "Cubic stored observations differ from x-x^3")
        rational_nodes, rational_values = list(map(Fraction, nodes)), list(map(Fraction, values))
        require(errors, all(y == x-x**3 for x, y in zip(rational_nodes, rational_values)),
                "Exact-rational cubic observation check failed")
        require(errors, row["stage_count"] == len(row["stages"])
                and row["background_n"] == row["stages"][-1]["n"], "Cubic stage ledger failed")
        trace_check(errors, row["trace"], nodes, row["stages"], row["query_count"], row["trace_sha256"])
        exact_errors, polygon_energy, residual_energy = [], Decimal(0), Decimal(0)
        for i, (u, v) in enumerate(zip(nodes, nodes[1:])):
            h = v-u
            xstar = ((u*u+u*v+v*v)/3).sqrt()
            exact_errors.append((xstar-u)*(v-xstar)*(xstar+u+v))
            polygon_energy += (values[i+1]-values[i])**2/h
            residual_energy += 3*((u+v)/2)**2*h**3+h**5/20
        require(errors, close(max(exact_errors), row["actual_error"], CERT_REL_TOL),
                "Cubic analytic per-gap error check failed")
        require(errors, close(polygon_energy, row["energy2"], CERT_REL_TOL)
                and close(polygon_energy+residual_energy, Decimal(4)/5, CERT_REL_TOL),
                "Cubic independent energy identities failed")
        rational_energy, rational_residual = Fraction(0), Fraction(0)
        for i, (u, v) in enumerate(zip(rational_nodes, rational_nodes[1:])):
            h = v-u
            rational_energy += (rational_values[i+1]-rational_values[i])**2/h
            rational_residual += 3*((u+v)/2)**2*h**3+h**5/20
        require(errors, rational_energy+rational_residual == Fraction(4, 5),
                "Exact-rational cubic energy/variance identity failed")
        require(errors, 0 <= dec(row["actual_error"]) <= dec(row["certificate"]) <= dec(row["epsilon"]),
                "Cubic actual error <= certificate <= epsilon failed")
        require(errors, row["peak_not_sampled_exact_rational"]
                and all(3*Fraction(x)**2 != 1 for x in nodes[1:-1]), "Cubic peak nonalignment check failed")
        if row["method"] == "uniform":
            require(errors, row["query_count"] == row["background_n"]-1, "Cubic uniform node count failed")
        record("cubic_primary:"+"|".join(case), errors)

    repeats = index(saved["precision_checks"])
    record("cubic_precision_coverage", [] if set(repeats) == expected else
           ["Expected all six cubic 80-digit repeats"], count=len(repeats))
    for case, row in repeats.items():
        errors = []
        base = primary[case]
        nodes80 = list(map(dec, row["nodes_80"]))
        trace_check(errors, row["trace_80"], nodes80, row["stages_80"],
                    row["query_count_80"], row["trace_sha256_80"])
        require(errors, row["primary_dps"] == 50 and row["repeat_dps"] == 80,
                "Cubic repeat precision labels differ")
        require(errors, row["trace_80"] == base["trace"] and row["same_query_trace"],
                "Complete raw ordered 50/80 cubic traces differ")
        require(errors, row["trace_sha256_50"] == row["trace_sha256_80"] == base["trace_sha256"],
                "Complete cubic precision trace hashes differ")
        require(errors, nodes80 == list(map(dec, base["nodes"])) and row["same_final_nodes"],
                "Cubic precision final nodes differ")
        require(errors, list(map(dec, row["values_80"])) == list(map(dec, base["values"])),
                "Cubic precision final observed values differ")
        require(errors, row["query_count_50"] == row["query_count_80"] == base["query_count"],
                "Cubic precision counts differ")
        require(errors, row["background_n_50"] == row["background_n_80"] == base["background_n"]
                and row["same_background_n"] and row["same_stage_count"]
                and len(row["stages_80"]) == base["stage_count"], "Cubic precision stages differ")
        require(errors, dec(row["certificate_50"]) == dec(base["certificate"]),
                "Cubic precision primary certificate baseline differs")
        absolute, relative = difference(row["certificate_50"], row["certificate_80"])
        require(errors, relative <= CERT_REL_TOL and 0 <= dec(row["certificate_80"]) <= dec(row["epsilon"]),
                "Cubic precision certificate check failed")
        detail = dict(case="|".join(case), absolute_difference=absolute, relative_difference=relative)
        precision_summary.append(detail)
        record("cubic_precision:"+detail["case"], errors, **detail)

    direct = index(saved["engine_reference_checks"])
    record("cubic_direct_coverage", [] if set(direct) == {("adaptive", "0.002")} else
           ["Expected the predeclared cubic direct comparison"], count=len(direct))
    for case, row in direct.items():
        errors = []
        base = primary[case]
        nodes = list(map(dec, row["nodes_direct"]))
        trace_check(errors, row["trace_direct"], nodes, row["stages_direct"],
                    row["query_count_direct"], row["trace_sha256_direct"])
        require(errors, row["dps"] == 50, "Cubic direct precision differs")
        require(errors, row["trace_direct"] == base["trace"] and row["same_query_trace"],
                "Complete raw cubic heap/direct traces differ")
        require(errors, row["trace_sha256_direct"] == row["trace_sha256_heap"] == base["trace_sha256"],
                "Cubic direct trace hashes differ")
        require(errors, nodes == list(map(dec, base["nodes"])) and row["same_final_nodes"]
                and list(map(dec, row["values_direct"])) == list(map(dec, base["values"])),
                "Cubic direct final data differ")
        require(errors, row["query_count_direct"] == row["query_count_heap"] == base["query_count"],
                "Cubic direct query counts differ")
        require(errors, row["same_background_n"] and row["same_stage_count"]
                and len(row["stages_direct"]) == base["stage_count"]
                and row["stages_direct"][-1]["n"] == base["background_n"], "Cubic direct stages differ")
        require(errors, dec(row["certificate_direct"]) == dec(row["certificate_heap"])
                == dec(base["certificate"]), "Cubic direct certificate differs")
        record("cubic_direct:"+"|".join(case), errors)
    return dict(status="passed" if all(c["passed"] for c in checks) else "failed",
                source_sha256=hashlib.sha256(raw).hexdigest(),
                counts=dict(primary=len(primary), precision=len(repeats), heap_direct=len(direct), checks=len(checks)),
                precision_summary=dict(max_absolute=maximum(precision_summary, "absolute_difference"),
                                       max_relative=maximum(precision_summary, "relative_difference")),
                scope="Saved raw ordered traces rehashed and compared; analytic gap/energy identities recomputed, without rerunning recovery",
                checks=checks, failures=[c for c in checks if not c["passed"]])


def verify(directory):
    names = ("single_results.json", "multilevel_results.json",
             "multilevel_precision80.json")
    raw = {name: (directory/name).read_bytes() for name in names}
    saved = {name: json.loads(data, parse_float=Decimal)
             for name, data in raw.items()}
    single, multi, multi80 = (saved[name] for name in names)
    checks, precision_single, precision_multi = [], [], []

    def record(name, errors=(), **details):
        checks.append(dict(name=name, passed=not errors, errors=list(errors), **details))

    def require(errors, condition, description):
        if not condition:
            errors.append(description)

    source_errors = []
    source_hashes = single["metadata"]["source_sha256"]
    require(source_errors, set(source_hashes) == {"local_recovery.py", "run_single_level.py"},
            "Single-level source checksum file set differs")
    for name, expected_hash in source_hashes.items():
        require(source_errors, hashlib.sha256((directory/name).read_bytes()).hexdigest() == expected_hash,
                f"Single-level source checksum differs: {name}")
    record("single_source_checksums", source_errors)

    primary = indexed(single["records"], True)
    expected_single = {(m, s, e) for m in ("adaptive", "uniform")
                       for s in ("0", "0.0001", "0.001")
                       for e in ("0.02", "0.01", "0.005", "0.002", "0.001",
                                 "0.0005", "0.0002")}
    record("single_case_coverage", [] if set(primary) == expected_single else
           ["Expected 42 distinct method/slack/tolerance cases"], count=len(primary))
    for case, row in primary.items():
        errors = []
        nodes = list(map(dec, row["nodes"]))
        values = list(map(dec, row["values"]))
        gaps = [b-a for a, b in zip(nodes, nodes[1:])]
        require(errors, row["dps"] == 50, "Primary precision must be 50")
        require(errors, bool(HASH.fullmatch(row["trace_sha256"])), "Malformed trace hash")
        require(errors, nodes[0] == 0 and nodes[-1] == 1 and all(h > 0 for h in gaps),
                "Nodes must form a strictly increasing endpoint partition")
        require(errors, len(nodes) == len(values), "Node/value lengths differ")
        require(errors, row["query_count"] == row["total_query_count"] == len(nodes)-2,
                "Single-level query ledger differs from internal node count")
        require(errors, all(close(y, x*(1-x), CERT_REL_TOL)
                            for x, y in zip(nodes, values)), "Stored data differ from parabola")
        actual_error = max(gaps)**2/4
        energy = (1-sum(h**3 for h in gaps))/3
        require(errors, close(actual_error, row["actual_error"], CERT_REL_TOL),
                "Analytic max-gap error identity failed")
        require(errors, close(energy, row["energy2"], CERT_REL_TOL),
                "Independent polygon energy identity failed")
        require(errors, 0 <= dec(row["actual_error"]) <= dec(row["certificate"])
                <= dec(row["epsilon"]), "Actual error <= certificate <= epsilon failed")
        if row["method"] == "uniform":
            require(errors, row["query_count"] == row["background_n"]-1,
                    "Uniform node count differs from background_n-1")
        record("single_primary:"+"|".join(case), errors)

    precision = indexed(single["precision_checks"], True)
    selected = {(s, e) for s, e in [("0", "0.0002"), ("0.0001", "0.0005"),
                                  ("0.001", "0.002"), ("0.001", "0.0002")]}
    expected_precision = {(m, s, e) for m in ("adaptive", "uniform") for s, e in selected}
    record("single_precision_coverage", [] if set(precision) == expected_precision else
           ["Expected the eight specified 50/80-digit checks"], count=len(precision))
    for case, row in precision.items():
        errors = []
        base = primary[case]
        require(errors, row["primary_dps"] == 50 and row["check_dps"] == 80,
                "Precision labels differ from 50/80")
        require(errors, row["trace_sha256_50"] == row["trace_sha256_80"] == base["trace_sha256"],
                "Complete query-trace SHA256 values differ")
        require(errors, row["same_query_trace"] and row["same_final_nodes"],
                "Saved raw trace/node comparison failed")
        require(errors, row["query_count_50"] == row["query_count_80"] == base["query_count"],
                "Precision-repeat query counts differ")
        require(errors, dec(row["certificate_50"]) == dec(base["certificate"]),
                "Precision-check baseline certificate differs from primary record")
        absolute, relative = difference(row["certificate_50"], row["certificate_80"])
        require(errors, relative <= CERT_REL_TOL, "Precision certificate discrepancy exceeds 1e-40")
        require(errors, 0 <= dec(row["certificate_80"]) <= dec(row["epsilon"]),
                "80-digit certificate exceeds epsilon")
        detail = dict(case="|".join(case), absolute_difference=absolute, relative_difference=relative)
        precision_single.append(detail)
        record("single_precision:"+detail["case"], errors, **detail)

    references = indexed(single["engine_reference_checks"], True)
    record("heap_direct_coverage", [] if set(references) == expected_single else
           ["Expected 42 saved heap/direct comparisons"], count=len(references))
    for case, row in references.items():
        errors = []
        base = primary[case]
        require(errors, row["same_query_count"] and row["same_trace_sha256"]
                and row["same_certificate_decimal"], "Saved heap/direct comparison failed")
        require(errors, row["query_count"] == base["query_count"], "Heap/direct count baseline differs")
        require(errors, row["trace_sha256_reference"] == row["trace_sha256_current"]
                == base["trace_sha256"], "Complete heap/direct trace hashes differ")
        require(errors, dec(row["certificate_reference"]) == dec(row["certificate_current"])
                == dec(base["certificate"]), "Serialized heap/direct certificates differ")
        record("heap_direct:"+"|".join(case), errors)
    zero = single["metadata"]["zero_input_check"]
    record("single_zero_input", [] if zero["query_count"] == 3 and dec(zero["certificate"]) == 0
           else ["Saved zero strict-pilot path failed"])

    rows = indexed(multi["rows"])
    expected_multi = {(b, e) for b in ("1", "1.5", "2")
                      for e in ("0.02", "0.01", "0.005", "0.002", "0.001", "0.0005")}
    record("multilevel_case_coverage", [] if set(rows) == expected_multi else
           ["Expected 18 beta/tolerance cases"], count=len(rows))
    for case, row in rows.items():
        errors = []
        levels = row["level_rows"]
        cert = dec(row["certificate_high_precision"])
        require(errors, row["dps"] == 50 and row["status"] == "success", "Primary status/precision failed")
        require(errors, 0 <= cert <= dec(row["epsilon"]), "Computed certificate exceeds epsilon")
        require(errors, close(cert, row["certificate"]), "Float/high-precision certificate disagreement")
        require(errors, 0 <= dec(row["sampled_error"]) <= dec(row["certificate"]),
                "Sampled-error diagnostic exceeds certificate")
        require(errors, row["weighted_query_cost"] == sum(r["cost"] for r in levels),
                "Weighted cost does not equal the level ledger")
        require(errors, row["total_cumulative_calls"] == sum(r["new_cumulative_calls"] for r in levels),
                "Raw cumulative-call count does not equal the level ledger")
        require(errors, row["cumulative_requests"] == row["total_cumulative_calls"]+row["cache_hits"],
                "Cache request ledger failed")
        require(errors, row["sum_local_node_counts"] == sum(r["local_nodes"] for r in levels),
                "Local-node aggregate failed")
        require(errors, [r["level"] for r in levels] == list(range(row["opened_levels"])),
                "Synthetic nonzero hierarchy must have all opened levels active")
        require(errors, close(sum(dec(r["tolerance"]) for r in levels), dec(row["epsilon"])/2),
                "Local tolerances do not sum to epsilon/2")
        require(errors, dec(row["tail_certificate"]) <= dec(row["epsilon"])/2,
                "Tail certificate exceeds epsilon/2")
        require(errors, close(sum(dec(r["certificate"]) for r in levels)
                              +dec(row["tail_certificate"]), cert), "Certificate ledger failed")
        require(errors, bool(HASH.fullmatch(row["cumulative_trace_sha256"])), "Malformed cumulative hash")
        for level in levels:
            j = level["level"]
            require(errors, level["cost"] == 2**j*level["new_cumulative_calls"],
                    f"Level {j} cost differs from 2^j times actual calls")
            require(errors, 0 <= dec(level["certificate"]) <= dec(level["tolerance"]),
                    f"Level {j} local certificate exceeds its tolerance")
            require(errors, bool(HASH.fullmatch(level["trace_sha256"])), f"Malformed local hash at level {j}")
        record("multilevel_primary:"+"|".join(case), errors)

    repeats = indexed(multi80["rows"])
    expected_repeats = {(b, e) for b in ("1", "1.5", "2") for e in ("0.02", "0.0005")}
    record("multilevel_precision_coverage", [] if set(repeats) == expected_repeats else
           ["Expected six endpoint 80-digit repeats"], count=len(repeats))
    counts = ("weighted_query_cost", "total_cumulative_calls", "cumulative_requests",
              "cache_hits", "sum_local_node_counts", "opened_levels")
    local_counts = ("local_nodes", "new_cumulative_calls", "cost", "background_n")
    for case, row in repeats.items():
        errors = []
        base = rows[case]
        require(errors, row["dps"] == 80 and row["status"] == "success", "Repeat status/precision failed")
        require(errors, row["cumulative_trace_sha256"] == base["cumulative_trace_sha256"],
                "Complete cumulative-query trace hashes differ")
        for field in counts:
            require(errors, row[field] == base[field], f"Precision-repeat {field} differs")
        level80 = {r["level"]: r for r in row["level_rows"]}
        level50 = {r["level"]: r for r in base["level_rows"]}
        require(errors, level80.keys() == level50.keys(), "Precision-repeat active levels differ")
        require(errors, [r["level"] for r in row["level_rows"]]
                == [r["level"] for r in base["level_rows"]],
                "Precision-repeat level order/uniqueness differs")
        max_local_absolute = max_local_relative = Decimal(0)
        for j in level80.keys() & level50.keys():
            high, low = level80[j], level50[j]
            require(errors, high["trace_sha256"] == low["trace_sha256"], f"Complete local trace differs at level {j}")
            for field in local_counts:
                require(errors, high[field] == low[field], f"Level {j} {field} differs")
            for field in ("certificate", "tolerance", "amplitude_bound"):
                require(errors, high[field] == low[field], f"Serialized level {j} {field} differs")
            absolute, relative = difference(low["certificate"], high["certificate"])
            max_local_absolute = max(max_local_absolute, absolute)
            max_local_relative = max(max_local_relative, relative)
        absolute, relative = difference(base["certificate_high_precision"], row["certificate_high_precision"])
        require(errors, relative <= CERT_REL_TOL, "Global precision certificate discrepancy exceeds 1e-40")
        require(errors, row["tail_certificate"] == base["tail_certificate"], "Serialized tail certificates differ")
        require(errors, 0 <= dec(row["certificate_high_precision"]) <= dec(row["epsilon"]),
                "80-digit multilevel certificate exceeds epsilon")
        detail = dict(case="|".join(case), absolute_difference=absolute, relative_difference=relative,
                      max_local_serialized_absolute_difference=max_local_absolute,
                      max_local_serialized_relative_difference=max_local_relative)
        precision_multi.append(detail)
        record("multilevel_precision:"+detail["case"], errors, **detail)

    report = dict(status="passed" if all(c["passed"] for c in checks) else "failed",
        scope="Saved-data consistency and recorded SHA256 comparisons; no algorithm reruns or interval validation",
        source_files_sha256={name: hashlib.sha256(data).hexdigest() for name, data in raw.items()},
        counts=dict(single_primary=len(primary), single_precision=len(precision),
                    heap_direct=len(references), multilevel_primary=len(rows), multilevel_precision=len(repeats)),
        certificate_relative_tolerance=str(CERT_REL_TOL),
        precision_summary=dict(single_max_absolute=maximum(precision_single,"absolute_difference"),
                               single_max_relative=maximum(precision_single,"relative_difference"),
                               multilevel_max_absolute=maximum(precision_multi,"absolute_difference"),
                               multilevel_max_relative=maximum(precision_multi,"relative_difference"),
                               local_multilevel_certificate_comparison="Exact equality of stored double-precision decimals; higher-precision local certificates were not serialized"),
        limitations=["Trace SHA256 agreement checks recorded complete traces, not re-executed traces.",
                     "Legacy parabolic final-node agreement is the saved 50/80 comparison flag; its raw 80-digit nodes are not retained.",
                     "Legacy heap/direct reference hashes and certificates are embedded summaries; their raw direct records are not required.",
                     "High-precision agreement does not establish finite-precision honesty or bound rounding error.",
                     "Multilevel sampled error is a diagnostic mesh estimate, not a continuous supremum."],
        checks=checks, failures=[c for c in checks if not c["passed"]])
    report["legacy_check_count"] = len(checks)
    if (directory/"cubic_results.json").exists():
        try:
            cubic = verify_cubic(directory)
        except (OSError, ValueError, KeyError, TypeError, ArithmeticError) as error:
            cubic = dict(status="failed", failures=[dict(name="cubic_input_or_schema", error=str(error))])
        report["cubic_verification"] = cubic
        report["failures"].extend(cubic["failures"])
        if cubic["status"] != "passed":
            report["status"] = "failed"
    else:
        report["cubic_verification"] = dict(status="not_present", checks=[], failures=[])
    return report, multi["rows"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=HERE)
    args = parser.parse_args()
    destination = args.directory/"numerics_verification.json"
    try:
        with localcontext() as context:
            context.prec = 120
            report, rows = verify(args.directory)
        columns = ("beta", "epsilon", "dps", "weighted_query_cost", "total_cumulative_calls",
                   "cumulative_requests", "cache_hits", "sum_local_node_counts", "opened_levels",
                   "certificate_high_precision", "tail_certificate", "sampled_error",
                   "cost_over_theoretical_order", "cumulative_trace_sha256", "seconds")
        with (args.directory/"multilevel_results.csv").open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader()
            writer.writerows({k: row[k] for k in columns} for row in rows)
    except (OSError, ValueError, KeyError, TypeError, ArithmeticError) as error:
        report = dict(status="failed", failures=[dict(name="input_or_schema", error=str(error))])
    destination.write_text(json.dumps(report, indent=2, default=str)+"\n")
    summary = {k:report[k] for k in ("status", "counts", "legacy_check_count", "precision_summary") if k in report}
    if "cubic_verification" in report:
        summary["cubic_verification"] = {k:v for k,v in report["cubic_verification"].items()
                                         if k in ("status", "counts", "precision_summary")}
    print(json.dumps(summary, indent=2, default=str))
    if report["failures"]:
        print(json.dumps(report["failures"], indent=2, default=str), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
