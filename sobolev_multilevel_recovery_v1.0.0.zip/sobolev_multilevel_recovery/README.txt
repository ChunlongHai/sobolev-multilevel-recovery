Code and numerical records
Version 1.0.0 (4 November 2026)

Accompanies:
Adaptive Certification of Multilevel Recovery on Sobolev Norm Cones
Chunlong Hai, Yantao Li, and Jiazhen Wang

Installation
------------
Tested with Python 3.12, mpmath 1.3.0, and NumPy 2.3.5.
Run the following commands from the extracted archive directory:

  python3 -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt

Check the supplied records
-------------------------

  python verify_results.py

This checks source checksums, saved query counts, certificates, trace hashes,
precision comparisons, and error inequalities. It writes
numerics_verification.json and exits nonzero if a check fails.
It does not rerun the numerical experiments.

Regenerate the tables and figure sources
---------------------------------------

  python make_tables.py
  python make_figures.py --no-render

These commands regenerate the two tables and two TikZ figures from the saved
records. Figure previews in output/figures additionally require Tectonic with
pgfplots and pdftoppm; run make_figures.py without --no-render to render them.
The options --tectonic and --pdftoppm select the executables.

Rerun the experiments
--------------------

  python run_single_level.py --engine direct --output-prefix single_direct_reference
  python run_single_level.py --engine heap --compare-reference single_direct_reference.json
  python run_cubic.py
  python run_multilevel.py
  python run_multilevel.py --dps 80 --eps .02 .0005 --output multilevel_precision80.json
  python verify_results.py

The single-level pair also compares direct scanning with the priority-queue
implementation. Reruns overwrite the corresponding numerical records.

Files
-----
local_recovery.py: point-query recovery and certificates.
run_single_level.py: parabolic input x(1-x), 42 primary cases and 8
  higher-precision repeats.
run_cubic.py: cubic input x-x^3, 6 primary cases, 6 higher-precision repeats,
  and a direct-scan comparison.
run_multilevel.py: alternating two-shape cumulative hierarchy, with 18 primary
  cases. multilevel_precision80.json contains its 6 higher-precision repeats.
*_results.json: observations, numerical results, and execution records.
verify_results.py: saved-record consistency checks.
make_tables.py and make_figures.py: manuscript table and figure generation.
release.json: release version, source/data hashes, and checked case counts.
MANIFEST.sha256: checksums of all files in this release.

Numerical conventions
---------------------
Decisions use 50-digit mpmath arithmetic; selected runs are repeated at
80 digits. These computations evaluate the exact-model certificate formulas
with rounded arbitrary precision, rather than interval enclosures.
Parabolic and cubic interpolation errors use analytic gap formulas.
The multilevel error is a sampled diagnostic on a uniform grid augmented
with output knots and support endpoints; it is not an exact supremum and
does not control stopping. Runtime depends on the computing environment.

Source provenance
-----------------
The supplied records were regenerated with the release scripts on
4 November 2026. Their source hashes were captured before execution.
Query counts, traces, stopping stages, certificates, and error diagnostics
agree with the manuscript records. Scientific outputs were compared with
the previous records; runtime measurements may differ.

License
-------
The code, numerical records, and documentation in this release are provided
under the MIT License; see LICENSE.txt.
